# first_note.py：给它一张工具清单，问一个问题，看它交回来的是什么
import json
import llm, toolbox
import kb_tools                                   # 这一行把三样工具登记进工具箱

msg = llm.chat_msg([{"role": "user", "content": "我在哪篇笔记里记过切块要重叠？"}],
                   tools=toolbox.specs(["search_notes", "read_note"]))
print("它说的话：", repr(msg.get("content")))
for note in msg.get("tool_calls") or []:
    print("它递来的纸条：", note["function"]["name"], note["function"]["arguments"])
print("真去找了吗？没有。它只是写了一张纸条，等你去办")
