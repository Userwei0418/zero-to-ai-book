# raw.py：第一步，不用任何封装，亲手发一次请求，把寄出去的和收回来的都原样印出来
import json, os, urllib.request

body = {
    "model": os.environ["LLM_MODEL"],
    "messages": [{"role": "user", "content": "用一句话说说，个人知识库有什么用？"}],
}
print("寄出去的：")
print(json.dumps(body, ensure_ascii=False, indent=2))

req = urllib.request.Request(
    os.environ["LLM_BASE_URL"].rstrip("/") + "/chat/completions",
    data=json.dumps(body).encode("utf-8"),
    headers={"Content-Type": "application/json", "Authorization": "Bearer " + os.environ["LLM_API_KEY"]},
)
with urllib.request.urlopen(req, timeout=60) as resp:
    data = json.loads(resp.read().decode("utf-8"))

data["id"] = data.get("id", "")[:12] + "…"                  # 编号太长，截一截
print("\n收回来的：")
print(json.dumps(data, ensure_ascii=False, indent=2))
