# consolidate.py：整理一次。把“已整理至”之后的新记录交给模型，让它提修订；程序逐条验过再落地
# 用法：python3 consolidate.py
import json
import llm, memory

def consolidate(show=print):
    covered = min((memory.load(t)["covered"] for t in memory.topics()), key=memory.num, default="E-0")
    new = [e for e in memory.events() if memory.num(e["id"]) > memory.num(covered) and e["kind"] == "用户"]
    if not new:
        show("没有新记录要整理"); return
    current = "\n\n".join(memory.render(memory.load(t)) for t in memory.topics()) or "（还没有任何笔记）"
    ask = ("你在帮我维护记忆笔记。下面是现有的笔记，和这之后的新记录。\n"
           "请对每一条新记录，判断它对笔记意味着什么，给出修订，只输出 JSON："
           '{"revisions": [{"topic": "话题", "type": "补充|事实变化|认识纠正|条件细化|未决冲突", '
           '"text": "写进笔记的一句话", "replaces": 现在的第几条（只有事实变化、认识纠正要填）, "sources": ["E-n"]}]}\n'
           "类型的意思：补充=原来没有的新信息；事实变化=情况变了，旧的不是错而是过去了；认识纠正=原来理解错了；"
           "条件细化=在某种条件下另有说法，两条都对；未决冲突=说法打架，定不下来。\n"
           "话题尽量用现有的；sources 只能填新记录里的编号。\n\n"
           f"【现有笔记】\n{current}\n\n【新记录】\n" + "\n".join(f"{e['id']}（{e['day']}）：{e['text']}" for e in new))
    revs = llm.chat_json([{"role": "user", "content": ask}]).get("revisions", [])
    new_ids = {e["id"] for e in new}
    for r in revs:
        result = memory.apply(r, new_ids)
        show(f"  {r.get('type')}｜{r.get('topic')}｜{r.get('text')} {r.get('sources')}" + ("" if result == "ok" else f"  ✗ 没改：{result}"))
    last = new[-1]["id"]
    for t in memory.topics():                                 # 这一批都看过了：每篇笔记的边界推到最后一条
        n = memory.load(t); n["covered"] = last; memory.save(n)
    memory.record(f"整理了 {new[0]['id']} 到 {last}", kind="整理")   # 整理这件事本身也记一笔，但标明是整理产物

if __name__ == "__main__":
    consolidate()
    print(llm.bill())
