# python3 -m mykb <命令>：把前面十三章做的东西，收成一个别人装得上、用得了的小工具
#   doctor          先体检：环境、配置、接口、笔记、索引，哪儿不对说清楚怎么修
#   init 文件夹     新建一个笔记文件夹，放进几篇样例
#   index           给笔记建索引（第 5 章）
#   ask "问题"      从笔记里找、答、标出处、核对出处（第 5 章）
#   serve           作为 MCP 服务跑起来，给别的助手接（第 4 章）
# 配置全走环境变量：KB_DIR 笔记在哪；KB_MODE real|mock；LLM_BASE_URL、LLM_API_KEY、LLM_MODEL
import hashlib, json, os, shutil, sys, urllib.request
from . import __version__, llm
from .chunks import chunks_of

KB = os.environ.get("KB_DIR", "notes")
HERE = os.path.dirname(os.path.abspath(__file__))

def index():
    chunks = chunks_of(KB)
    for i in range(0, len(chunks), 16):
        for c, v in zip(chunks[i:i + 16], llm.embed([c["embed_text"] for c in chunks[i:i + 16]])):
            c["vector"] = [round(x, 5) for x in v]
    json.dump({"mode": llm.MODE, "model": os.environ.get("EMBED_MODEL", "qwen3.7-text-embedding"), "chunks": chunks},
              open(os.path.join(KB, "vectors.json"), "w", encoding="utf-8"), ensure_ascii=False)
    print(f"建好了：{len(set(c['file'] for c in chunks))} 篇，{len(chunks)} 块（{llm.MODE} 模式）")

def doctor():
    """一项一项查。✓ 好的，✗ 用不了、要先修，！ 能用但要注意"""
    bad = 0
    def say(ok, text, fix=""):
        nonlocal bad
        mark = {True: "✓", False: "✗", None: "！"}[ok]
        bad += ok is False
        print(f"  {mark} {text}" + (f"\n      → {fix}" if fix and ok is not True else ""))
    print(f"mykb {__version__} 体检")
    say(sys.version_info >= (3, 9), f"Python {sys.version.split()[0]}", "需要 3.9 或更新")
    say(True if llm.MODE == "real" else None, f"模式：{llm.MODE}",
        "演示模式：不联网，回答都是假的，只能用来看看流程" if llm.MODE == "mock" else "")
    if llm.MODE == "real":
        miss = [n for n in ("LLM_BASE_URL", "LLM_API_KEY") if not os.environ.get(n)]
        say(not miss, "接口地址和密钥" + (f"：缺 {'、'.join(miss)}" if miss else "已设好（密钥不显示）"),
            "export LLM_BASE_URL=…  export LLM_API_KEY=…；或者先用 KB_MODE=mock 看看")
        if not miss:
            try:
                req = urllib.request.Request(os.environ["LLM_BASE_URL"].rstrip("/") + "/models",
                                             headers={"Authorization": "Bearer " + os.environ["LLM_API_KEY"]})
                have = {m["id"] for m in json.load(urllib.request.urlopen(req, timeout=20))["data"]}
                say(True, f"接口连得上，平台上有 {len(have)} 个模型")
                for env, default in (("LLM_MODEL", "sensenova-6.8-flash-lite"), ("EMBED_MODEL", "qwen3.7-text-embedding"),
                                     ("RERANK_MODEL", "qwen3.7-text-rerank")):
                    m = os.environ.get(env, default)
                    say(m in have, f"{env} = {m}", "平台上没有这个模型，换一个列表里有的")
            except Exception as e:
                say(False, f"接口连不上：{str(e)[:60]}", "检查地址（要带 /v1 那一截）、密钥、网络")
    md = [f for f in os.listdir(KB) if f.endswith(".md")] if os.path.isdir(KB) else []
    say(bool(md), f"笔记文件夹 {KB}：{len(md)} 篇", f"python3 -m mykb init {KB}")
    vp = os.path.join(KB, "vectors.json")
    if md and not os.path.exists(vp):
        say(False, "还没有索引", "python3 -m mykb index")
    elif md:
        v = json.load(open(vp, encoding="utf-8"))
        say(v.get("mode") == llm.MODE, f"索引是 {v.get('mode')} 模式建的",
            f"现在是 {llm.MODE} 模式，两种模式的向量不通用，重建：python3 -m mykb index")
        now = {(c["file"], c["line"], c["hash"]) for c in chunks_of(KB)}
        old = {(c["file"], c["line"], c["hash"]) for c in v["chunks"]}
        stale = len(now ^ old)
        say(stale == 0 or None, "索引和笔记对得上" if not stale else f"索引过期了：{stale} 处对不上",
            "笔记改过，重建：python3 -m mykb index")
    print("体检完了：" + ("可以用" if not bad else f"{bad} 项要先修"))
    return bad

def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "doctor":
        sys.exit(1 if doctor() else 0)
    elif cmd == "init":
        dest = sys.argv[2]
        os.makedirs(dest, exist_ok=True)
        for f in os.listdir(os.path.join(HERE, "..", "sample_notes")):
            shutil.copy(os.path.join(HERE, "..", "sample_notes", f), dest)
        print(f"在 {dest} 放了几篇样例笔记。接着：KB_DIR={dest} python3 -m mykb index")
    elif cmd == "index":
        index()
    elif cmd == "ask":
        from .answer import answer, check
        reply, shown = answer(sys.argv[2], KB)
        print("答：", reply)
        problems = check(reply, shown, KB)
        print("核对：", "；".join(problems) if problems else "出处都对得上")
    elif cmd == "serve":
        from .mcp_stdio import serve
        from .toolbox import REGISTRY
        from . import kb_tools, semantic_tools
        kb_tools.KB = KB
        serve("my-kb", REGISTRY, ["find_notes", "search_notes", "read_note"])
    elif cmd in ("version", "--version"):
        print(__version__)
    else:
        print(open(__file__, encoding="utf-8").read().split("import")[0].replace("# ", ""))

if __name__ == "__main__":
    main()
