# recall.py 里加的几行（完整文件见 ch10/code/recall.py）
    ...
        if not notes:
            answer = msg.get("content") or ""
            if dug:                                          # 当前笔记不够，回去读了原话：这是一个“缺口”
                memory.record(f"问“{question}”时，当前笔记不够，读了原话 {' '.join(dug)}", kind="读取")
            memory.record(f"对“{question}”的回答：{answer}", kind="回答")   # 回答也记下，但它只是模型说的
            return answer
    ...
            if note["function"]["name"] == "read_events":
                dug += [i for i in (json.loads(note["function"]["arguments"] or "{}").get("ids", "")).split()]
