# naive.py：只在提示里说“请用 JSON”，看看十六篇笔记交回来的都是什么样
import json, os, sys
import llm

ASK = ('下面是我知识库里的一篇笔记。请用 JSON 回答，格式是 {"summary": "一句话摘要", "tags": ["标签1", "标签2", "标签3"]}\n\n')

folder = sys.argv[1]
kinds, all_tags = {}, set()
for name in sorted(os.listdir(folder)):
    if not name.endswith(".md") or name == "index.md":
        continue
    text = open(os.path.join(folder, name), encoding="utf-8").read()
    reply = llm.chat([{"role": "user", "content": ASK + text}])
    try:
        card = json.loads(reply)
        kind = "能直接读"
        all_tags.update(card.get("tags", []))
    except ValueError:
        kind = "外面包了 ```" if reply.lstrip().startswith("```") else "读不了"
    kinds.setdefault(kind, []).append(name)
    if kind != "能直接读" and len(kinds[kind]) == 1:
        print(f"【{kind}】{name} 交回来的开头：{reply[:60]!r}")

for kind, names in kinds.items():
    print(f"{kind}：{len(names)} 篇")
print(f"能读的那些里，一共出现了 {len(all_tags)} 个不同的标签：{'、'.join(sorted(all_tags)[:12])}……")
print(llm.bill())
