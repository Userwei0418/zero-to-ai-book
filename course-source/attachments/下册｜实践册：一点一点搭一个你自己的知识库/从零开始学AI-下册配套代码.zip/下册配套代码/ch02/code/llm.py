# llm.py：知识库和模型说话的唯一入口。整本下册都用它，后面每一章只往上加东西
# 换模型只改三个环境变量：LLM_BASE_URL、LLM_API_KEY、LLM_MODEL
# 第 2 章加了：chat_json（按格式交）和 check（逐条验）
import json, os, re, socket, time, urllib.error, urllib.request

LEDGER = {"calls": 0, "prompt": 0, "completion": 0, "seconds": 0.0}     # 一本小账：问了几次，读了多少，写了多少，等了多久

RETRY = {429, 500, 502, 503, 504}                                       # 值得再试一次的：太忙、对面出了岔子
class LLMError(Exception):
    pass

def _post(body, stream=False, timeout=120):
    req = urllib.request.Request(
        os.environ["LLM_BASE_URL"].rstrip("/") + "/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + os.environ["LLM_API_KEY"]})
    for attempt in range(4):
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:200]
            if e.code not in RETRY or attempt == 3:                     # 密钥错、地址错、参数错：再试也没用，直接说清楚
                raise LLMError(f"HTTP {e.code}：{detail}") from None
        except (urllib.error.URLError, TimeoutError, socket.timeout) as e:   # 第 2 章补上：读到一半等超时，是 socket.timeout
            if attempt == 3:
                raise LLMError(f"连不上：{e}") from None
        time.sleep(2 ** attempt)                                        # 等 1、2、4 秒再试

def _book(usage, began):
    LEDGER["calls"] += 1
    LEDGER["prompt"] += usage.get("prompt_tokens", 0)
    LEDGER["completion"] += usage.get("completion_tokens", 0)
    LEDGER["seconds"] += time.time() - began

def _parse(raw):
    """正常情况直接解析。有的平台偶尔把回来的内容末尾截掉一截，截掉的只是用量统计，回答本身是完整的：把回答抠出来"""
    try:
        return json.loads(raw)
    except ValueError:
        if '"content":' not in raw:
            raise LLMError(f"回来的内容不完整：{raw[-80:]!r}") from None
        start = raw.index('"content":') + len('"content":')
        content, _ = json.JSONDecoder().raw_decode(raw, start)
        usage = {k: int(m.group(1)) for k in ("prompt_tokens", "completion_tokens")
                 for m in [re.search(f'"{k}":(\\d+)', raw)] if m}
        return {"choices": [{"message": {"content": content}, "finish_reason": "stop"}], "usage": usage or None}   # 截掉的是账，回答本身已收全

def chat(messages, model=None, temperature=0, timeout=120, **extra):
    """交出一串对话，拿回它的回答（一段文字）"""
    began = time.time()
    body = {"model": model or os.environ["LLM_MODEL"], "messages": messages, "temperature": temperature, **extra}
    with _post(body, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8", "replace")
    data = _parse(raw)
    _book(data.get("usage", {}), began)
    choice = data["choices"][0]
    done(choice, data.get("usage"))
    return choice["message"].get("content") or ""

class NotDone(LLMError):
    """它回了话，但这一次不能算完成"""

def done(choice, usage):
    """什么才算一次调用完成：说完了（stop），而且真有内容。写满了、被拦了、递了纸条，都不算"""
    why = choice.get("finish_reason")
    text = (choice.get("message") or {}).get("content") or ""
    if usage is None or "completion_tokens" not in (usage or {}):
        LEDGER["unknown"] = LEDGER.get("unknown", 0) + 1            # 账不全：记下“不知道”，不当成 0
    if why == "stop" and text.strip():
        return
    raise NotDone({"length": f"写到上限被掐断了，只有前半截：{text[-30:]!r}",
                   "content_filter": "被平台的内容过滤拦下了",
                   "tool_calls": "它没说话，递来了一张要用工具的纸条"}.get(why, f"停下的原因是 {why!r}，内容{'为空' if not text.strip() else '不完整'}"))

def chat_json(messages, schema=None, **kw):
    """要它按格式交：交回来必须是一个 JSON 对象。给了 schema，就把格式连同允许的取值一起交给平台去管
    读不出来就报错，不偷偷再问一遍：要不要重来，由调用的人决定"""
    if schema:
        fmt = {"type": "json_schema", "json_schema": {"name": "card", "strict": True, "schema": schema}}
    else:
        fmt = {"type": "json_object"}
    text = chat(messages, response_format=fmt, **kw)
    try:
        data = json.loads(text)
    except ValueError:
        raise NotDone(f"交回来的不是 JSON：{text[:60]!r}") from None
    if not isinstance(data, dict):
        raise NotDone(f"交回来的是 JSON，但不是一个对象：{text[:60]!r}")
    return data

def check(card, rules):
    """逐条验一张卡片。rules 是一张小表：哪些字段必须有、多长、取值只能从哪儿挑。返回问题清单，空的就是合格"""
    problems = []
    for key, rule in rules.items():
        if key not in card:
            problems.append(f"缺了 {key}")
            continue
        value = card[key]
        if rule.get("type") == "text":
            if not isinstance(value, str) or not value.strip():
                problems.append(f"{key} 应该是一段字")
            elif len(value) > rule.get("max", 10**9):
                problems.append(f"{key} 太长了：{len(value)} 字，上限 {rule['max']}")
        if rule.get("type") == "list":
            if not isinstance(value, list):
                problems.append(f"{key} 应该是一个列表")
                continue
            low, high = rule.get("count", (0, 10**9)) if isinstance(rule.get("count"), tuple) else (rule.get("count", 0), rule.get("count", 10**9))
            if not low <= len(value) <= high:
                problems.append(f"{key} 应该 {low}{'' if low == high else '—' + str(high)} 个，交了 {len(value)} 个")
            outside = [v for v in value if "choices" in rule and v not in rule["choices"]]
            if outside:
                problems.append(f"{key} 里有不在词表里的：{'、'.join(map(str, outside))}")
            if len(set(map(str, value))) != len(value):
                problems.append(f"{key} 里有重复的")
    return problems

def stream(messages, model=None, temperature=0):
    """一边写一边交：每拿到一小段就交出来。用法：for piece in stream(...): print(piece, end="")"""
    began = time.time()
    body = {"model": model or os.environ["LLM_MODEL"], "messages": messages, "temperature": temperature,
            "stream": True, "stream_options": {"include_usage": True}}
    usage = {}
    with _post(body, stream=True) as resp:
        for raw in resp:                                                # 一行一行读：每行以 data: 开头
            line = raw.decode("utf-8").strip()
            if not line.startswith("data:") or line == "data: [DONE]":
                continue
            chunk = json.loads(line[5:])
            usage = chunk.get("usage") or usage                         # 用量在最后一块里
            for choice in chunk.get("choices", []):
                piece = (choice.get("delta") or {}).get("content")
                if piece:
                    yield piece
    _book(usage, began)

def bill(price_in=None, price_out=None):
    """把小账念出来。价格是“每百万 token 多少元”，各家不同，看你那家的价目表"""
    unknown = f"，其中 {LEDGER['unknown']} 次账不全，没算进去" if LEDGER.get("unknown") else ""
    line = (f"问了 {LEDGER['calls']} 次，读了 {LEDGER['prompt']} 个 token，写了 {LEDGER['completion']} 个，"
            f"一共等了 {LEDGER['seconds']:.1f} 秒{unknown}")
    if price_in is not None:
        cost = LEDGER["prompt"] / 1e6 * price_in + LEDGER["completion"] / 1e6 * price_out
        line += f"，按你给的价格大约 {cost:.4f} 元"
    return line
