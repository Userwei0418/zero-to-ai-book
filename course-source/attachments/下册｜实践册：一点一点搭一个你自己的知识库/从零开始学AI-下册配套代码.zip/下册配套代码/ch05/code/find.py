# find.py：按意思找。问题也算一个向量，和每一块比一比，最像的几块交回去；可以再让重排读一遍
import json, math, os
import llm

def _cos(a, b):
    return sum(x * y for x, y in zip(a, b)) / (math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b)))

def load(folder):
    return json.load(open(os.path.join(folder, "vectors.json"), encoding="utf-8"))["chunks"]

def find(question, chunks, k=3, rerank=False, pool=10):
    q = llm.embed([question])[0]
    ranked = sorted(chunks, key=lambda c: -_cos(q, c["vector"]))
    if not rerank:
        return [(c, round(_cos(q, c["vector"]), 3)) for c in ranked[:k]]
    pool_chunks = ranked[:pool]                              # 向量先粗筛出十块，重排只读这十块
    scores = llm.rerank(question, [c["embed_text"] for c in pool_chunks])
    return [(pool_chunks[i], round(s, 3)) for i, s in sorted(scores, key=lambda x: -x[1])[:k]]
