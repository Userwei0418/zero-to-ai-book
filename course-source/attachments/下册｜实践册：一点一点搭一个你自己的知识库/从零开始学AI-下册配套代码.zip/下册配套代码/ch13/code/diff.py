# diff.py：拿两份验收报告比一比。改了什么，哪道题变好了、哪道变坏了
# 用法：python3 diff.py 基线 新的
import json, sys

a, b = (json.load(open(f"report-{t}.json", encoding="utf-8")) for t in sys.argv[1:3])
print(f"{a['tag']}（{a['model']}）→ {b['tag']}（{b['model']}）")
worse = better = 0
for cid, x in a["cases"].items():
    y = b["cases"].get(cid)
    if not y or x["passed"] == y["passed"]:
        continue
    sign = "变坏" if y["passed"] < x["passed"] else "变好"
    worse += sign == "变坏"; better += sign == "变好"
    why = next((e for e in y["evidence"]), "")
    print(f"  {sign}  {cid}  {x['passed']}/{x['runs']} → {y['passed']}/{y['runs']}  {why[:70]}")
print(f"变坏 {worse} 道，变好 {better} 道，其余不变" if worse or better else "一道都没变")
