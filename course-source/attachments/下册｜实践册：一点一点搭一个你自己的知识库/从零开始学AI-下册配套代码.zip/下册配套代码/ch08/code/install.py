# install.py：把封好版的包装进你的助手。装之前先核对指纹，装完记下“装的是哪一版、当时每个文件长什么样”
# 用法：python3 install.py 包的文件夹 装到哪个 skills 文件夹
import json, os, shutil, sys
from pack import files_of

def install(src, dest_root):
    manifest = json.load(open(os.path.join(src, "MANIFEST.json"), encoding="utf-8"))
    now = files_of(src)
    if now != manifest["files"]:                                  # 封版以后被人动过：不装
        bad = [p for p in set(now) | set(manifest["files"]) if now.get(p) != manifest["files"].get(p)]
        raise SystemExit(f"指纹对不上，不装：{bad}")
    dest = os.path.join(dest_root, manifest["name"])
    if os.path.exists(dest):
        raise SystemExit(f"{dest} 已经有了。要升级，先用 upgrade_plan.py 看一看")
    shutil.copytree(src, dest)
    json.dump({"source": manifest["name"], "version": manifest["version"], "files": manifest["files"]},
              open(os.path.join(dest, ".installed.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"装好了 {manifest['name']} {manifest['version']} → {dest}")

if __name__ == "__main__":
    install(sys.argv[1], sys.argv[2])
