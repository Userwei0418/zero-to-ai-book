# oops.py：故意弄错几样，看它报什么错。先记住这几张脸，以后碰上了一眼就认得
import os
import llm

def attempt(label, **env):
    saved = {k: os.environ[k] for k in env}
    os.environ.update(env)
    try:
        llm.chat([{"role": "user", "content": "你好"}])
        print(f"{label}：居然通了")
    except llm.LLMError as e:
        print(f"{label}：{e}")
    finally:
        os.environ.update(saved)

attempt("密钥错了一位", LLM_API_KEY=os.environ["LLM_API_KEY"][:-1] + "x")
attempt("模型名拼错", LLM_MODEL="senseaudio-s2-flsah")
attempt("地址少了 /v1", LLM_BASE_URL=os.environ["LLM_BASE_URL"].rstrip("/").removesuffix("/v1") if hasattr(str, "removesuffix") else os.environ["LLM_BASE_URL"].rstrip("/")[:-3])
attempt("地址写错了域名", LLM_BASE_URL="https://api.senseaudio.example/v1")
