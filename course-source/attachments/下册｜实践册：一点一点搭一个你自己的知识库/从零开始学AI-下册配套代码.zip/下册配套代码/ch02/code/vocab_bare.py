# vocab_bare.py：同一张词表，去掉每个词后面那句“什么算”，用来对照
from rules import TOPICS

ASK = ("下面是我知识库里的一篇笔记。请用 JSON 回答，格式是 {\"summary\": \"一句话摘要，不超过 30 字\", \"topics\": [一到两个话题]}。\n"
       "话题只能从这张词表里挑一到两个真正相关的，不要自己造；只有一个相关就只写一个：" + "、".join(TOPICS) + "\n\n")
