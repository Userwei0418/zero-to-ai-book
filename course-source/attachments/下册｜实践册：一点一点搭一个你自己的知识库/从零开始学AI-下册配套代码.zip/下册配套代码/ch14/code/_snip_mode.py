# mykb/llm.py 里加的几行（完整文件见 ch14/code/mykb/mykb/llm.py）
MODE = os.environ.get("KB_MODE", "real")
if MODE == "mock":
    from . import mock

def _need(*names):
    missing = [n for n in names if not os.environ.get(n)]
    if missing:
        raise LLMError(f"真实模式缺了 {'、'.join(missing)}。设好环境变量再来；想先不联网试试，用 KB_MODE=mock（不会自动替你换）")

def _post(body, stream=False, timeout=120, path="/chat/completions"):
    _need("LLM_BASE_URL", "LLM_API_KEY")
    ...

def chat(messages, model=None, temperature=0, timeout=120, **extra):
    """交出一串对话，拿回它的回答（一段文字）"""
    if MODE == "mock":
        return mock.chat(messages)
    ...
# embed 和 rerank 开头也各加了一样的两行
