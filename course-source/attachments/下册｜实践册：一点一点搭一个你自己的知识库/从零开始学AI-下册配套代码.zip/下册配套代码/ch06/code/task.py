# task.py：一张任务卡，一本流水账
# 任务卡写清楚：要做成什么、怎样算做完、能用哪些工具、花多少算超支
# 流水账记下每一步。会改东西的动作，动手之前记一笔“要做”，做完再记一笔“做完了”
import json, os, time

TASKS = os.environ.get("TASKS_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "tasks"))

def new_card(task_id, goal, done_when, tools, writes, budget):
    card = {"id": task_id, "goal": goal, "done_when": done_when, "tools": tools, "writes": writes,
            "budget": budget, "created": time.strftime("%Y-%m-%d %H:%M")}
    os.makedirs(TASKS, exist_ok=True)
    path = os.path.join(TASKS, task_id + ".card.json")
    if not os.path.exists(path):                              # 卡片一旦写下就不改：重跑时读的还是同一张
        json.dump(card, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return json.load(open(path, encoding="utf-8"))

def log(task_id, **event):
    event["at"] = time.strftime("%H:%M:%S")
    with open(os.path.join(TASKS, task_id + ".log.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")
        f.flush(); os.fsync(f.fileno())                       # 真落到盘上再往下走：断电了，这一笔也在

def history(task_id):
    path = os.path.join(TASKS, task_id + ".log.jsonl")
    return [json.loads(l) for l in open(path, encoding="utf-8")] if os.path.exists(path) else []

def state(task_id):
    """翻流水账，分清三种：做完了的，没开始的，开了头却不知道结果的"""
    done, pending = {}, {}
    for e in history(task_id):
        if e["event"] == "intent":
            pending[e["op"]] = e
        elif e["event"] in ("done", "skipped"):
            pending.pop(e["op"], None)
            done[e["op"]] = e
    return done, pending
