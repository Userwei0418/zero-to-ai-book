# graduation.py：毕业项目走一遍。两天，两个会话，中间后台整理一次
import os, time
import llm, memory
from consolidate import consolidate
from harness import Session, start_kb

kb = start_kb()
print("【第一天，会话 A】")
a = Session("A", kb)
for rid, text in [("a1", "番茄炒蛋要放糖吗？"), ("a2", "帮我写一下这周的周报"), ("a3", "下周三上午我要去体检，要空腹。")]:
    print(f"你：{text}")
    t = time.time()
    print(f"助手（{time.time() - t:.0f} 秒前开始）：", end="")
    reply = a.send(text, request_id=rid)
    print(f"\n{reply}\n  （{time.time() - t:.1f} 秒）\n")
print("你：（网卡了一下，同一条“番茄炒蛋要放糖吗？”又发了一次）")
print("助手：", a.send("番茄炒蛋要放糖吗？", request_id="a1"), "\n")

print("【夜里，后台整理一次】")
consolidate(show=lambda s: print(" ", s.strip()), model="deepseek-v4.1-flash")
print()

print("【第二天，新开一个会话 B】")
b = Session("B", kb)
text = "我体检是哪天？要注意什么？"
print(f"你：{text}")
print("助手：", b.send(text, request_id="b1"))
print("\n" + llm.bill())
