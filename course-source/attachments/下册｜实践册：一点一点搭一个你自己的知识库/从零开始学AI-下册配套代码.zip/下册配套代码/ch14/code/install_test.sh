# install_test.sh：装作一个第一次拿到这个包的朋友，在一个空文件夹里从头装一遍
# 用法：bash install_test.sh dist/mykb-0.1.0.tar.gz
set -u
PKG=$(cd "$(dirname "$1")" && pwd)/$(basename "$1")
HOME_DIR=$(mktemp -d); cd "$HOME_DIR"
echo "① 解开，核对指纹"; tar xzf "$PKG" && shasum -a 256 "$PKG" | cut -c1-16
cd mykb
echo; echo "② 什么都没配，先体检"
env -u LLM_API_KEY -u LLM_BASE_URL KB_DIR=notes python3 -m mykb doctor; echo "   退出码 $?"
echo; echo "③ 没有密钥，用演示模式走一遍"
KB_MODE=mock python3 -m mykb init notes > /dev/null
KB_MODE=mock KB_DIR=notes python3 -m mykb index
KB_MODE=mock KB_DIR=notes python3 -m mykb ask "番茄炒蛋要不要放糖？"
echo; echo "④ 拿着演示模式建的索引，切到真实模式"
KB_DIR=notes python3 -m mykb doctor | grep "索引是\|→\|体检完了"
echo; echo "⑤ 配好密钥，重建，真问一次"
KB_DIR=notes python3 -m mykb index
KB_DIR=notes python3 -m mykb ask "番茄炒蛋要不要放糖？"
echo; echo "⑥ 当作 MCP 服务跑起来，问一句有哪些工具"
printf '%s\n%s\n' '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"t","version":"0"}}}' '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}' \
  | KB_DIR=notes python3 -m mykb serve | python3 -c "import sys,json;[print('  ',[t['name'] for t in json.loads(l)['result'].get('tools',[])] or json.loads(l)['result']['serverInfo']) for l in sys.stdin]"
