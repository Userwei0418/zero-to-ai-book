# kb_server.py：我的知识库，做成一个 MCP 服务。哪个助手接上它，都能查我的笔记
# 默认只开两样只读的。加 --allow-write 启动，才把会写的 add_clip 也开出去
# 笔记放在哪个文件夹，由环境变量 KB_DIR 决定
import sys
from mcp_stdio import serve
from toolbox import REGISTRY
import kb_tools                                   # 登记三样工具

names = ["search_notes", "read_note"] + (["add_clip"] if "--allow-write" in sys.argv else [])
serve("my-kb", REGISTRY, names)
