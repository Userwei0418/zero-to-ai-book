# spaces.py：记忆分空间放。个人的、项目的、公共经验目录，各有各的主人和成员
# 规矩只有几条，都由程序守：
#   默认只读得到自己所在的空间；每一次读都重新核对一遍，撤了权，下一次就读不到
#   个人的经验要进公共目录，得先整理成一张“经验卡”：去掉私事、写明适用范围、主人点头，才发布
#   别的空间用一张卡，是“采纳”：抄一份到本地，记着它出自哪张卡的哪一版；原卡撤回，采纳的那份跟着标出来
#   每一次读、拒、发、采、撤，都记进审计
import json, os, time

HOME = os.environ.get("SPACES_DIR", "spaces")
P = lambda *a: os.path.join(HOME, *a)

def _load(*a, default=None):
    return json.load(open(P(*a), encoding="utf-8")) if os.path.exists(P(*a)) else default

def _save(obj, *a):
    os.makedirs(os.path.dirname(P(*a)), exist_ok=True)
    json.dump(obj, open(P(*a), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

def audit(who, action, what, ok):
    with open(P("audit.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps({"at": time.strftime("%H:%M:%S"), "who": who, "action": action, "what": what, "ok": ok}, ensure_ascii=False) + "\n")

# ---------- 空间和成员 ----------
def make_space(name, owner, members, notes):
    _save({"owner": owner, "members": members, "notes": notes}, "spaces", name + ".json")

def space(name):
    return _load("spaces", name + ".json")

def can_read(who, name):
    s = space(name)
    return bool(s) and (who == s["owner"] or who in s["members"])

def read_space(who, name):
    ok = can_read(who, name)                                   # 每一次都现查，不靠上一次的结果
    audit(who, "读空间", name, ok)
    if not ok:
        return f"{who} 不在“{name}”里，读不到"
    return "\n".join(f"- {n['text']} [{name}:{n['src']}]" for n in space(name)["notes"])

def remove_member(by, name, who):
    s = space(name)
    if by != s["owner"]:
        return f"只有主人能移人"
    s["members"] = [m for m in s["members"] if m != who]
    _save(s, "spaces", name + ".json")
    audit(by, "移出成员", f"{name}:{who}", True)               # 撤权以后，读过的仍在审计里，抹不掉
    return "ok"

# ---------- 经验卡 ----------
PRIVATE = ["我这包", "我家", "我妈", "小满", "阿青", "老周", "小林"]    # 发出去之前要去掉的：私人物件、人名

def check_card(card):
    problems = [f"正文里有私人信息：{w}" for w in PRIVATE if w in card.get("text", "")]
    if not card.get("scope"):
        problems.append("没写适用范围")
    if not card.get("evidence"):
        problems.append("没写依据")
    return problems

def publish(owner, card, approved):
    problems = check_card(card)
    if problems or not approved:
        audit(owner, "发布经验卡", card.get("title"), False)
        return "没发布：" + ("；".join(problems) if problems else "主人没点头")
    cat = _load("catalog.json", default={})
    cid = card["id"]
    version = cat.get(cid, {}).get("version", 0) + 1
    cat[cid] = {**card, "owner": owner, "version": version, "status": "有效"}
    _save(cat, "catalog.json")
    audit(owner, "发布经验卡", f"{cid}@v{version}", True)
    return f"已发布 {cid}@v{version}"

def read_catalog(who):
    audit(who, "读经验目录", "全部", True)
    cat = _load("catalog.json", default={})
    return "\n".join(f"- {c['title']}：{c['text']}（适用：{c['scope']}；{c['status']}）[经验卡 {cid}@v{c['version']}]"
                     for cid, c in cat.items()) or "目录是空的"

def adopt(who, name, cid):
    s, cat = space(name), _load("catalog.json", default={})
    if who != s["owner"] and who not in s["members"]:
        return f"{who} 不在“{name}”里"
    c = cat[cid]
    s["notes"].append({"text": c["text"], "src": f"采纳自 {cid}@v{c['version']}", "derived_from": f"{cid}@v{c['version']}"})
    _save(s, "spaces", name + ".json")
    audit(who, "采纳经验卡", f"{cid}@v{c['version']} → {name}", True)
    return "ok"

def withdraw(owner, cid, why):
    cat = _load("catalog.json", default={})
    if cat[cid]["owner"] != owner:
        return "只有发卡的人能撤"
    cat[cid]["status"] = f"已撤回：{why}"
    _save(cat, "catalog.json")
    n = 0
    for f in os.listdir(P("spaces")):                          # 撤回要传下去：采纳过它的地方，都标出来
        s = _load("spaces", f)
        for note in s["notes"]:
            if note.get("derived_from", "").startswith(cid + "@"):
                note["text"] = "（原卡已撤回，先别照做）" + note["text"].replace("（原卡已撤回，先别照做）", "")
                n += 1
        _save(s, "spaces", f)
    audit(owner, "撤回经验卡", f"{cid}：{why}", True)
    return f"已撤回，{n} 处采纳跟着标了出来"

# ---------- 委托：“@某人的助手”，是一次受限的请求，不是拿到这个人的全部权限 ----------
def request(who, name, change):
    """改安排、对外说话、做承诺：都只排进主人的待办，记下谁请的、在哪儿、要什么，等主人点头"""
    s = space(name)
    if not s or not can_read(who, name):
        audit(who, "请求改动", name, False)
        return f"{who} 不在“{name}”里，不能替你提"
    todo = _load("todo.json", default=[])
    todo.append({"from": who, "owner": s["owner"], "space": name, "change": change, "status": "等主人点头"})
    _save(todo, "todo.json")
    audit(who, "请求改动", f"{name}：{change}", True)
    return f"已经排进 {s['owner']} 的待办，等 {s['owner']} 点头才生效"

def decide(owner, k, yes):
    todo = _load("todo.json", default=[])
    item = todo[k]
    if item["owner"] != owner:
        return "只有主人能定"
    item["status"] = "主人同意，已生效" if yes else "主人没同意"
    if yes:
        s = space(item["space"]); s["notes"].append({"text": item["change"], "src": f"{owner} 同意了 {item['from']} 的请求"})
        _save(s, "spaces", item["space"] + ".json")
    _save(todo, "todo.json")
    audit(owner, "处理请求", item["change"], yes)
    return item["status"]
