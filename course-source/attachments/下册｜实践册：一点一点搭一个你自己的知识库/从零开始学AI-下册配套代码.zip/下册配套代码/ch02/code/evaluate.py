# evaluate.py：一份小考卷。十篇笔记，每篇写上“一定该有的那个话题”，看它答对几篇
# 用法：python3 evaluate.py 提示文件 模型名 [模型名 ...]   提示文件比如 vocab_ask 或 vocab_bare
import importlib, json, sys
import llm
from rules import RULES

ASK = importlib.import_module(sys.argv[1]).ASK          # 考同一份卷子，换一份提示

gold = json.load(open("gold.json", encoding="utf-8"))
for model in sys.argv[2:]:
    right, wrong = 0, []
    for name, must in gold.items():
        text = open("../../kb/notes/" + name, encoding="utf-8").read()
        try:
            card = llm.chat_json([{"role": "user", "content": ASK + text}], model=model, timeout=60)
            problems = llm.check(card, RULES)
        except llm.LLMError as e:
            card, problems = {}, [str(e)[:40]]
        if must in card.get("topics", []) and not problems:
            right += 1
        else:
            wrong.append(f"{name}：交了 {card.get('topics')}，该有 {must}" + (f"（{'；'.join(problems)}）" if problems else ""))
    print(f"{sys.argv[1]} × {model}：{right}/{len(gold)}")
    for w in wrong:
        print("   ✗", w)
print(llm.bill())
