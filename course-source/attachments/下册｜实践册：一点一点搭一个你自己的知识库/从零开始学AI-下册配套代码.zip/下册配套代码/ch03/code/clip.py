# clip.py：把一段网页剪藏交给它，让它整理成一篇笔记存进知识库。存之前，先问你
# 用法：python3 clip.py 剪藏文件
import json, sys
import llm
from ask import ask_kb

def ask_me(name, args):
    """会改东西的工具，每一次都先给你看它要干什么，你说 y 才办"""
    print(f"  ┌ 它想用 {name}：")
    for k, v in args.items():
        print(f"  │ {k}：{v[:60]}{'…' if len(v) > 60 else ''}")
    ok = input("  └ 同意吗？(y/n) ").strip().lower() == "y"
    print("    →", "同意" if ok else "不同意")
    return ok

clip = open(sys.argv[1], encoding="utf-8").read()
print("答：", ask_kb("把下面这段剪藏整理成一篇笔记存进我的知识库，去掉评论和广告，标题十来个字。\n\n" + clip,
                    tools=["search_notes", "add_clip"], ask=ask_me))
print(llm.bill())
