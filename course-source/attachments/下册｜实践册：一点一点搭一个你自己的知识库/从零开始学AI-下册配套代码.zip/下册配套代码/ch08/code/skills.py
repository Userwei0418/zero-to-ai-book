# skills.py：做法包。三层披露：
#   第一层 目录：每个包一行，名字加一句“什么时候用”。每次对话都带着，只占几十个字
#   第二层 正文：它觉得用得上，才用 use_skill 取出 SKILL.md 的正文
#   第三层 附件：正文里提到的 references/ 下的文件，它要用，再用 read_skill_file 取
# 格式和各家通用：一个文件夹，里面一个 SKILL.md，开头三根横线之间写 name 和 description
import os, re
from toolbox import tool

HOME = os.environ.get("SKILLS_DIR", "skills")

def read_card(folder):
    text = open(os.path.join(HOME, folder, "SKILL.md"), encoding="utf-8").read()
    m = re.match(r"---\n(.*?)\n---\n(.*)", text, re.S)
    if not m:
        raise ValueError(f"{folder}/SKILL.md 开头缺了 --- 包起来的那一段")
    head = {k.strip(): v.strip() for k, v in (l.split(":", 1) for l in m.group(1).splitlines() if ":" in l)}
    return head, m.group(2).strip()

def catalog():
    rows = []
    for folder in sorted(os.listdir(HOME)):
        if os.path.exists(os.path.join(HOME, folder, "SKILL.md")):
            head, _ = read_card(folder)
            rows.append(f"- {head['name']}：{head['description']}")
    return "\n".join(rows)

@tool("取出一个做法包的正文，照着做", name="做法包的名字")
def use_skill(name):
    if name not in os.listdir(HOME):
        return f"没有叫 {name} 的做法包"
    return read_card(name)[1]

@tool("读做法包里附带的一个文件，比如 references/rules.md", name="做法包的名字", path="包里的相对路径")
def read_skill_file(name, path):
    full = os.path.normpath(os.path.join(HOME, name, path))
    if not full.startswith(os.path.normpath(os.path.join(HOME, name)) + os.sep) or not os.path.isfile(full):
        return f"{name} 包里没有 {path}"                       # 只能读包里面的文件
    return open(full, encoding="utf-8").read()
