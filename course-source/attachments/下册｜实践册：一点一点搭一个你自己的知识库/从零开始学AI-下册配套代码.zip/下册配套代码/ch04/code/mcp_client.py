# mcp_client.py：我们自己的小助手，换一种接法：不再 import kb_tools，而是像别的助手一样，通过 MCP 去接
# 它不知道工具是谁写的、用什么语言写的，只认 MCP 这套说法
# 用法：python3 mcp_client.py "问题" 服务的启动命令...
import json, subprocess, sys
import llm

class MCPServer:
    def __init__(self, command):
        self.proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        self.n = 0
        self.rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                                "clientInfo": {"name": "my-assistant", "version": "0"}})
        self.send({"jsonrpc": "2.0", "method": "notifications/initialized"})

    def send(self, message):
        self.proc.stdin.write(json.dumps(message, ensure_ascii=False) + "\n"); self.proc.stdin.flush()

    def rpc(self, method, params):
        self.n += 1
        self.send({"jsonrpc": "2.0", "id": self.n, "method": method, "params": params})
        reply = json.loads(self.proc.stdout.readline())
        if "error" in reply:
            raise RuntimeError(reply["error"]["message"])
        return reply["result"]

    def tools(self):
        """把 MCP 的说明书，换回给模型看的写法。和服务那边的 mcp_tools 正好反过来"""
        return [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                  "parameters": t["inputSchema"]}}
                for t in self.rpc("tools/list", {})["tools"]]

    def call(self, name, arguments):
        result = self.rpc("tools/call", {"name": name, "arguments": arguments})
        text = "\n".join(c["text"] for c in result["content"] if c["type"] == "text")
        return ("（工具报错）" if result.get("isError") else "") + text

    def close(self):
        self.proc.stdin.close(); self.proc.wait()

SYSTEM = "你是我的知识库助手。回答前先用工具在我的笔记里找；找到了，要说出出自哪篇笔记的第几行。笔记里没有的，就说没找到。"

if __name__ == "__main__":
    server = MCPServer(sys.argv[2:])
    tools = server.tools()
    print("接上了，服务交出来的工具：", [t["function"]["name"] for t in tools])
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": sys.argv[1]}]
    for _ in range(6):
        msg = llm.chat_msg(messages, tools=tools)
        notes = msg.get("tool_calls") or []
        if not notes:
            print("答：", msg.get("content")); break
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for note in notes:
            try:
                result = server.call(note["function"]["name"], json.loads(note["function"]["arguments"] or "{}"))
            except (ValueError, RuntimeError) as e:
                result = f"办不了：{e}"
            print(f"  经 MCP 办：{note['function']['name']} {note['function']['arguments']}")
            messages.append({"role": "tool", "tool_call_id": note["id"], "content": result})
    server.close()
    print(llm.bill())
