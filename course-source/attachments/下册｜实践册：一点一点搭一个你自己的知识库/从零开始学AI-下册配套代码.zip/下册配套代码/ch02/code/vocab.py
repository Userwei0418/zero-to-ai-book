# vocab.py：把词表交给它，再把交回来的每一张卡片逐条验一遍
import os, sys
import llm
from rules import RULES
from vocab_ask import ASK

folder = sys.argv[1]
good, bad = 0, []
for name in sorted(os.listdir(folder)):
    if not name.endswith(".md") or name == "index.md":
        continue
    text = open(os.path.join(folder, name), encoding="utf-8").read()
    card = llm.chat_json([{"role": "user", "content": ASK + text}])
    problems = llm.check(card, RULES)
    if problems:
        bad.append((name, card, problems))
    else:
        good += 1
print(f"合格 {good} 篇，不合格 {len(bad)} 篇")
for name, card, problems in bad:
    print(f"  {name}：{'；'.join(problems)}")
print(llm.bill())
