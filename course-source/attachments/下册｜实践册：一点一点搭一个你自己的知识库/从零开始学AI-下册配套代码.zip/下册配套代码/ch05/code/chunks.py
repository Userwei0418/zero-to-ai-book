# chunks.py：把笔记切成小块。每一块都带着它的出处：哪篇笔记，第几行到第几行
# 我们的笔记短，一行一个要点，就一行一块；太长的行，按 MAX 个字切开，前后重叠 OVERLAP 个字
import hashlib, os

MAX, OVERLAP = 200, 40

def chunks_of(folder):
    out = []
    for name in sorted(os.listdir(folder)):
        if not name.endswith(".md") or name == "index.md":
            continue
        lines = open(os.path.join(folder, name), encoding="utf-8").read().splitlines()
        title = lines[0].lstrip("# ").strip() if lines else name
        for no, line in enumerate(lines[1:], 2):
            text = line.strip().lstrip("- ").strip()
            if len(text) < 6:                              # 空行、太短的行（日期、署名）不单独成块
                continue
            for start in range(0, len(text), MAX - OVERLAP):
                piece = text[start:start + MAX]
                out.append({"file": name, "line": no, "text": piece,
                            "embed_text": f"{title}：{piece}",        # 带上标题再算向量：一行“加一小勺糖”，单看不知道在说什么菜
                            "hash": hashlib.sha1(line.encode("utf-8")).hexdigest()[:10]})   # 原文这一行的指纹，日后用来查它变没变
                if start + MAX >= len(text):
                    break
    return out
