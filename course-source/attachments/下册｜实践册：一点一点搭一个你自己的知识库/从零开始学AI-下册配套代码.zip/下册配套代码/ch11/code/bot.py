# bot.py：一个人的助手。谁在问、在哪个空间里问，决定它读得到什么
# 它的工具只有两样：读一个空间、读公共经验目录。两样都带着“谁在问”，权限由 spaces.py 现查
import json
import llm, spaces

def tools_for(who):
    return [{"type": "function", "function": {"name": "read_space", "description": "读一个空间里的笔记",
             "parameters": {"type": "object", "required": ["name"], "properties": {"name": {"type": "string", "description": "空间名"}}}}},
            {"type": "function", "function": {"name": "read_catalog", "description": "读公共经验目录里的经验卡",
             "parameters": {"type": "object", "properties": {}}}},
            {"type": "function", "function": {"name": "request_change", "description": "请空间的主人改一条安排、或者替主人对外说一句话。不会立刻生效，要等主人点头",
             "parameters": {"type": "object", "required": ["room", "change"], "properties": {
                 "room": {"type": "string", "description": "空间名"}, "change": {"type": "string", "description": "要改什么、要说什么"}}}}}]

def ask(who, room, question, show=print):
    system = (f"你是“{room}”里的助手。现在提问的是 {who}。你知道的空间有：{room}、小满（小满的个人空间），还有公共经验目录。"
              "回答前用工具去读；读不到的，就说读不到，不要猜。每句话标出处。")
    messages = [{"role": "system", "content": system}, {"role": "user", "content": question}]
    for _ in range(5):
        msg = llm.chat_msg(messages, tools=tools_for(who))
        notes = msg.get("tool_calls") or []
        if not notes:
            return msg.get("content") or ""
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for n in notes:
            args = json.loads(n["function"]["arguments"] or "{}")
            name = n["function"]["name"]
            if name == "read_space":
                result = spaces.read_space(who, args.get("name", ""))
            elif name == "read_catalog":
                result = spaces.read_catalog(who)
            else:                                            # 替人改安排、替人说话：只排进主人的待办，不当场办
                result = spaces.request(who, args.get("room", room), args.get("change", ""))
            show(f"    {who} 的助手 {n['function']['name']} {args.get('name') or args.get('change', '')} → {result.splitlines()[0][:40]}")
            messages.append({"role": "tool", "tool_call_id": n["id"], "content": result})
    return "（没答完）"
