# context_for.py：只把这一次用得上的规矩交出去。规矩分三种：
#   总规矩（每次都读）  这一类笔记的规矩（看要处理哪一类）  这一件事的做法（看要做什么）
# 交出去的时候，一并写明每一段出自哪个文件、指纹是多少：事后查得到“这一次依据了什么”
import hashlib, os

HERE = os.path.dirname(os.path.abspath(__file__))
MAX_CHARS = 3000                                            # 交出去的规矩，最多这么长：超了就报错，逼你拆

def context_for(kinds, recipe):
    """kinds：这次要处理哪几类笔记，比如 ["剪藏"]；recipe：做哪件事，比如 "整理收件箱" """
    paths = ["rules/AGENTS.md"] + [f"rules/{k}/AGENTS.md" for k in kinds] + [f"recipes/{recipe}.md"]
    parts, sources = [], []
    for p in paths:
        full = os.path.join(HERE, p)
        if not os.path.exists(full):
            raise FileNotFoundError(f"缺一份规矩：{p}。先补上，或者把这一类说清楚")   # 缺了就停，不假装有
        text = open(full, encoding="utf-8").read().strip()
        parts.append(text)
        sources.append(f"{p}@{hashlib.sha1(text.encode('utf-8')).hexdigest()[:8]}")
    text = "\n\n".join(parts)
    if len(text) > MAX_CHARS:
        raise ValueError(f"规矩太长了：{len(text)} 字，上限 {MAX_CHARS}")
    return text, sources

def everything():
    """对照用：所有规矩、所有做法一股脑儿交出去"""
    parts, sources = [], []
    for root, _, files in sorted(os.walk(HERE)):
        for f in sorted(files):
            p = os.path.relpath(os.path.join(root, f), HERE)
            if f.endswith(".md") and p.startswith(("rules", "recipes")):
                parts.append(open(os.path.join(HERE, p), encoding="utf-8").read().strip())
                sources.append(p)
    return "\n\n".join(parts), sources

if __name__ == "__main__":
    text, sources = context_for(["剪藏"], "整理收件箱")
    print("这一次交出去的：", sources, f"共 {len(text)} 字")
    all_text, all_sources = everything()
    print("全部规矩：", len(all_sources), f"份，共 {len(all_text)} 字")
    try:
        context_for(["菜谱"], "整理收件箱")
    except FileNotFoundError as e:
        print("要一类没写过规矩的：", e)
