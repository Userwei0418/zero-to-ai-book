# memory.py（第 10 章版）：多了观测者用的几样维护动作：改写一条（补细节、补条件）、解决待核对、改话题名
# memory.py：记性分两层
#   原始记录 events.jsonl：你说过的每一句，按先后编号 E-1、E-2……只往后加，一个字不改
#   当前笔记 notes/<话题>.json：现在有效的理解。每一条都带着锚点，指回它出自哪几条原始记录
#   每篇笔记还记着“已整理至 E-n”：它吸收到了哪一条为止
import json, os, time

HOME = os.environ.get("MEM_DIR", "mem")
EVENTS = lambda: os.path.join(HOME, "events.jsonl")
NOTES = lambda: os.path.join(HOME, "notes")
TYPES = {"补充", "事实变化", "认识纠正", "条件细化", "未决冲突"}

# ---------- 原始记录：只往后加 ----------
def events():
    return [json.loads(l) for l in open(EVENTS(), encoding="utf-8")] if os.path.exists(EVENTS()) else []

def record(text, kind="用户", day=None):
    os.makedirs(HOME, exist_ok=True)
    e = {"id": f"E-{len(events()) + 1}", "day": day or time.strftime("%m-%d"), "kind": kind, "text": text}
    with open(EVENTS(), "a", encoding="utf-8") as f:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return e["id"]

def num(eid):
    return int(eid.split("-")[1])

# ---------- 当前笔记 ----------
def load(topic):
    p = os.path.join(NOTES(), topic + ".json")
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {"topic": topic, "covered": "E-0", "now": [], "past": [], "open": []}

def save(note):
    os.makedirs(NOTES(), exist_ok=True)
    json.dump(note, open(os.path.join(NOTES(), note["topic"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    open(os.path.join(NOTES(), note["topic"] + ".md"), "w", encoding="utf-8").write(render(note))   # 给人看的那一份

def topics():
    return sorted(f[:-5] for f in os.listdir(NOTES()) if f.endswith(".json")) if os.path.exists(NOTES()) else []

def render(note):
    a = lambda item: "".join(f"[{s}]" for s in item["src"])
    out = [f"# {note['topic']}" + (f"（以前叫：{'、'.join(note['aliases'])}）" if note.get("aliases") else ""),
           f"已整理至：{note['covered']}", "", "## 现在"]
    out += [f"{i + 1}. {x['text']} {a(x)}" for i, x in enumerate(note["now"])] or ["（无）"]
    if note["open"]:
        out += ["", "## 待核对"] + [f"{i + 1}. {x['text']} {a(x)}" for i, x in enumerate(note["open"])]
    if note["past"]:
        out += ["", "## 以前"] + [f"- {x['text']} {a(x)} → {x['why']}" for x in note["past"]]
    return "\n".join(out) + "\n"

# ---------- 修订：程序按类型落地，先验后改 ----------
def apply(rev, new_ids):
    """rev = {topic, type, text, replaces(第几条，可选), sources:[E-..]}。不合格的，说清楚为什么，不改"""
    if not rev.get("topic") or any(ch in rev["topic"] for ch in "/\\:"):   # 第 10 章补上：话题名会变成文件名，不许带 / \ :
        return f"话题名不能带 / \\ 这类符号：{rev.get('topic')!r}"
    if rev.get("type") not in TYPES:
        return f"不认识的修订类型：{rev.get('type')}"
    src = rev.get("sources") or []
    if not src:
        return "没有来源：不能凭空改笔记"
    by_id = {e["id"]: e for e in events()}
    for s in src:
        if s not in by_id:
            return f"来源 {s} 不存在"
        if by_id[s]["kind"] != "用户":
            return f"来源 {s} 是整理时自己写的记录，不能拿来当证据"
        if s not in new_ids:
            return f"来源 {s} 不在这一批新记录里"
    note = load(rev["topic"])
    item = {"text": rev["text"], "src": src}
    k = rev.get("replaces")
    old = note["now"][k - 1] if isinstance(k, int) and 1 <= k <= len(note["now"]) else None
    if rev["type"] in ("事实变化", "认识纠正") and not old:
        return f"“{rev['type']}”要指明替换现在的第几条"
    if rev["type"] == "补充":
        note["now"].append(item)
    elif rev["type"] == "事实变化":                          # 旧状态不是错了，是过去了：按时点留着
        note["now"][k - 1] = item
        note["past"].append({**old, "why": f"到 {src[0]}（{by_id[src[0]]['day']}）为止"})
    elif rev["type"] == "认识纠正":                          # 旧判断错了：记下被谁纠正
        note["now"][k - 1] = item
        note["past"].append({**old, "why": f"理解有误，被 {src[0]} 纠正"})
    elif rev["type"] == "条件细化":                          # 不二选一：新旧各管一种情形
        note["now"].append(item)
    elif rev["type"] == "未决冲突":                          # 定不下来：两边都留着，等人核对
        note["open"].append(item)
    save(note)
    return "ok"

# ---------- 第 10 章：维护动作。来源可以是任何一条“用户”记录，但不能是整理、读取、回答这些系统自己留下的 ----------
def _check_sources(src):
    by_id = {e["id"]: e for e in events()}
    if not src:
        return "没有来源"
    for s in src:
        if s not in by_id:
            return f"来源 {s} 不存在"
        if by_id[s]["kind"] != "用户":
            return f"来源 {s} 是“{by_id[s]['kind']}”记录，不是用户说的，不能当证据"
    return None

def maintain(op):
    kind, topic = op.get("op"), op.get("topic")
    if topic not in topics():
        return f"没有 {topic} 这个话题"
    note = load(topic)
    if kind == "rename":                                     # 改话题名：旧名字记进别名，按旧名也找得到
        new = op.get("new_name", "").strip()
        if not new or new in topics():
            return "新名字是空的，或者已经有了"
        note["aliases"] = note.get("aliases", []) + [topic]
        note["topic"] = new
        save(note)
        for ext in (".json", ".md"):
            os.remove(os.path.join(NOTES(), topic + ext))
        return "ok"
    bad = _check_sources(op.get("sources") or [])
    if bad:
        return bad
    if kind == "rewrite":                                    # 补细节、补条件：旧的写法挪到“以前”，写明为什么改
        k = op.get("item")
        if not isinstance(k, int) or not 1 <= k <= len(note["now"]):
            return "要指明改现在的第几条"
        old = note["now"][k - 1]
        note["now"][k - 1] = {"text": op["text"], "src": sorted(set(old["src"]) | set(op["sources"]), key=num)}
        note["past"].append({**old, "why": f"{op.get('reason', '改写')}，依据 {' '.join(op['sources'])}"})
    elif kind == "resolve":                                  # 待核对的那一条，有了定论
        k = op.get("open")
        if not isinstance(k, int) or not 1 <= k <= len(note["open"]):
            return "要指明解决待核对的第几条"
        old = note["open"].pop(k - 1)
        note["now"].append({"text": op["text"], "src": op["sources"]})
        note["past"].append({**old, "why": f"已核实，依据 {' '.join(op['sources'])}"})
    else:
        return f"不认识的维护动作：{kind}"
    save(note)
    return "ok"
