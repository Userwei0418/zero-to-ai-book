# index_kb.py（第 2 章版）：目录照格式交。一份给人看的 index.md，一份给程序读的 index.json
# 卡片不合格的，不偷偷替它改，也不偷偷再问一遍：单独列出来，等你看一眼
# 用法：python3 index_kb.py 笔记文件夹
import json, os, sys
import llm
from rules import RULES, source_of
from vocab_ask import ASK

folder = sys.argv[1]
cards, held = [], []
for name in sorted(os.listdir(folder)):
    if not name.endswith(".md") or name == "index.md":
        continue
    text = open(os.path.join(folder, name), encoding="utf-8").read()
    title = text.splitlines()[0].lstrip("# ").strip()
    try:
        card = llm.chat_json([{"role": "user", "content": ASK + text}], timeout=60)
        problems = llm.check(card, RULES)
    except llm.LLMError as e:
        card, problems = {}, [f"没拿到：{str(e)[:40]}"]
    if problems:
        held.append({"file": name, "problems": problems, "got": card})
        continue
    cards.append({"file": name, "title": title, "summary": card["summary"],
                  "tags": [source_of(name)] + card["topics"]})

json.dump({"cards": cards, "held": held}, open(os.path.join(folder, "index.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
rows = [f"| [{c['title']}]({c['file']}) | {c['summary']} | {'、'.join(c['tags'])} |" for c in cards]
md = "# 我的知识库目录\n\n| 笔记 | 一句话 | 标签 |\n|-|-|-|\n" + "\n".join(rows) + "\n"
if held:
    md += "\n## 待你看一眼\n\n" + "\n".join(f"- {h['file']}：{'；'.join(h['problems'])}" for h in held) + "\n"
open(os.path.join(folder, "index.md"), "w", encoding="utf-8").write(md)

print(f"进了目录 {len(cards)} 篇，待你看一眼 {len(held)} 篇")
for h in held:
    print(f"   {h['file']}：{'；'.join(h['problems'])}")
by_tag = {}
for c in cards:
    for t in c["tags"]:
        by_tag.setdefault(t, []).append(c["title"])
print("按标签一筛：", "；".join(f"{t} {len(v)} 篇" for t, v in sorted(by_tag.items(), key=lambda x: -len(x[1]))))
print(llm.bill())
