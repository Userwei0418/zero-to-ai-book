# build_index.py：给每一块算一个向量，存进 vectors.json。笔记改了，重跑一遍
# 用法：python3 build_index.py 笔记文件夹
import json, os, sys
import llm
from chunks import chunks_of

folder = sys.argv[1]
chunks = chunks_of(folder)
for i in range(0, len(chunks), 16):                        # 一次交 16 块，少跑几趟
    batch = chunks[i:i + 16]
    for c, v in zip(batch, llm.embed([c["embed_text"] for c in batch])):
        c["vector"] = [round(x, 5) for x in v]
json.dump({"model": os.environ.get("EMBED_MODEL", "qwen3.7-text-embedding"), "chunks": chunks},
          open(os.path.join(folder, "vectors.json"), "w", encoding="utf-8"), ensure_ascii=False)
print(f"{len(set(c['file'] for c in chunks))} 篇笔记，切成 {len(chunks)} 块，每块一串 {len(chunks[0]['vector'])} 个数")
print("头两块：")
for c in chunks[:2]:
    print(f"  {c['file']} 第 {c['line']} 行：{c['text'][:30]}…  向量开头：{c['vector'][:4]}")
print(llm.bill())
