# recall.py（第 10 章版）：回答完，把“这次读了原话”和“我的回答”各记一笔，给观测者看
# recall.py：拿记性回答问题。三条路：
#   一 目录 → 当前笔记 → 回答                      平常的问题
#   二 目录 → 当前笔记 → 顺着锚点读原始记录 → 回答  问“为什么”“当时怎么说的”
#   三 还没整理的新记录，直接读原文                 笔记的边界之后又发生了事
import json, sys
import llm, memory, toolbox
from toolbox import tool

@tool("读一个话题的当前笔记", topic="话题名")
def read_memory(topic):
    return memory.render(memory.load(topic)) if topic in memory.topics() else f"没有 {topic} 这个话题"

@tool("顺着锚点读原始记录的原话", ids="编号，空格隔开，比如：E-3 E-7")
def read_events(ids):
    by_id = {e["id"]: e for e in memory.events()}
    return "\n".join(f"{i}（{by_id[i]['day']}）：{by_id[i]['text']}" if i in by_id else f"{i}：没有这一条" for i in ids.split())

def recall(question, show=print):
    covered = min((memory.load(t)["covered"] for t in memory.topics()), key=memory.num, default="E-0")
    fresh = [e for e in memory.events() if memory.num(e["id"]) > memory.num(covered) and e["kind"] == "用户"]
    index = "\n".join(f"- {t}：{len(memory.load(t)['now'])} 条现在有效，{len(memory.load(t)['open'])} 条待核对" for t in memory.topics())
    system = ("你是我的助手，用我的记忆笔记回答。先看目录，再读相关话题的笔记；问到“为什么”“当时怎么说的”，顺着锚点读原话。"
              "每句话标出处 [E-n]。笔记里标着“待核对”的，不要替我选一个，说清楚两边。\n\n"
              f"【目录】（笔记已整理至 {covered}）\n{index}\n"
              + ("\n【还没整理进笔记的新记录，比笔记新】\n" + "\n".join(f"{e['id']}（{e['day']}）：{e['text']}" for e in fresh) if fresh else ""))
    messages = [{"role": "system", "content": system}, {"role": "user", "content": question}]
    dug = []
    for _ in range(6):
        msg = llm.chat_msg(messages, tools=toolbox.specs(["read_memory", "read_events"]))
        notes = msg.get("tool_calls") or []
        if not notes:
            answer = msg.get("content") or ""
            if dug:                                          # 当前笔记不够，回去读了原话：这是一个“缺口”
                memory.record(f"问“{question}”时，当前笔记不够，读了原话 {' '.join(dug)}", kind="读取")
            memory.record(f"对“{question}”的回答：{answer}", kind="回答")   # 回答也记下，但它只是模型说的
            return answer
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for note in notes:
            show(f"  {note['function']['name']} {note['function']['arguments']}")
            if note["function"]["name"] == "read_events":
                dug += [i for i in (json.loads(note["function"]["arguments"] or "{}").get("ids", "")).split()]
            messages.append({"role": "tool", "tool_call_id": note["id"], "content": toolbox.call(note, ["read_memory", "read_events"], None)})
    return "（没答完）"

if __name__ == "__main__":
    print("答：", recall(sys.argv[1]))
