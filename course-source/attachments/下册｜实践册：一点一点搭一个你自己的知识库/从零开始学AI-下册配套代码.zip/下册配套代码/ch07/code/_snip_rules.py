# agent.py 里加的几行（完整文件见 ch07/code/agent.py）
def run(card, ask, show=print, rules=None):
    ...
    if rules:
        text, sources = rules
        system = "这一次要守的规矩：\n\n" + text + "\n\n" + system
        task.log(card["id"], event="rules", sources=sources)              # 记下这一次依据了哪几份规矩
    ...
