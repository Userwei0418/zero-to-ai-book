# upgrade_plan.py：新版出来了，要不要升？先出一份只读的计划，不动你的任何文件
# 三方一比：当初装的那一版（.installed.json）、你现在手上的、新版
# 用法：python3 upgrade_plan.py 已装的包文件夹 新版包的文件夹
import json, os, sys
from pack import files_of

def plan(installed, new):
    record_path = os.path.join(installed, ".installed.json")
    mine = files_of(installed)
    theirs = json.load(open(os.path.join(new, "MANIFEST.json"), encoding="utf-8"))
    if not os.path.exists(record_path):                          # 当初是手抄过来的，没留记录
        print("不知道当初装的是哪一版：分不清哪些是你改的、哪些是上游改的。下面只列出和新版不一样的文件，逐个看：")
        for p in sorted(set(mine) | set(theirs["files"])):
            if mine.get(p) != theirs["files"].get(p):
                print(f"  ？ {p}")
        return
    record = json.load(open(record_path, encoding="utf-8"))
    print(f"{record['source']}：装的是 {record['version']}，新版是 {theirs['version']}")
    base, up = record["files"], theirs["files"]
    for p in sorted(set(base) | set(mine) | set(up)):
        b, m, u = base.get(p), mine.get(p), up.get(p)
        if m == u:
            continue                                              # 和新版一样，没什么可做
        if b is None and m is None:
            print(f"  新文件      {p}：新版加的，可以拿过来")
        elif b is None and u is None:
            print(f"  你自己加的  {p}：新版里没有，留着")
        elif u is None:
            print(f"  上游删了    {p}：" + ("你没改过，可以删" if m == b else "可你改过，先别删，看看为什么"))
        elif m == b:
            print(f"  可以直接换  {p}：你没改过，上游改了")
        elif u == b:
            print(f"  保留你的    {p}：你改过，上游没动")
        else:
            print(f"  冲突        {p}：你改过，上游也改了，得你自己合")

if __name__ == "__main__":
    plan(sys.argv[1], sys.argv[2])
