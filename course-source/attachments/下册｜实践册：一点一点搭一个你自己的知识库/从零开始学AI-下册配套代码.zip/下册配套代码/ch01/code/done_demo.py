# done_demo.py：三种“它回了话，可不能算完成”的情形。先认清楚，第 2 章起都要用
import llm

ASK = [{"role": "user", "content": "用三句话介绍番茄工作法。"}]
for label, extra in [("正常", {}), ("只给它 12 个 token 的地方", {"max_tokens": 12})]:
    try:
        print(f"{label}：{llm.chat(ASK, **extra)[:40]}……")
    except llm.NotDone as e:
        print(f"{label}：不算完成。{e}")

import os
os.environ["LLM_BASE_URL"] = os.environ["LLM_BASE_URL"]
try:
    llm._post({"model": os.environ["LLM_MODEL"], "messages": ASK}, timeout=0.05)
except llm.LLMError as e:
    print(f"只等 0.05 秒：{e}")
print(llm.bill())
