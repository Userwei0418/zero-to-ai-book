# observer.py：独立观测者。它不回答问题，只在旁边看着流水账，隔一会儿整理一次
# 它有自己的进程、自己的上下文、可以用自己的模型；它看得到的只有流水账和笔记，看不到任何一次对话的内部
# 每一轮做三件事：
#   一 新的“用户”记录 → 五种修订（第 9 章那一套）
#   二 新的“读取”记录（回答时当前笔记不够、回去读了原话）→ 把缺的那点补进笔记，下次不用再回去读
#   三 通读一遍受影响的笔记 → 话题名还贴切吗？“现在”里有没有缺条件的、看着打架的？
# 用法：python3 observer.py --watch   （或者不带参数，只整理一轮）
import json, os, sys, time
import llm, memory
from consolidate import consolidate

STATE = lambda: os.path.join(memory.HOME, "observer.json")
MODEL = os.environ.get("OBSERVER_MODEL")                    # 观测者可以用另一个模型，也可以和回答的用同一个
LOG = lambda: os.path.join(memory.HOME, "observer.log")

def log(line):
    with open(LOG(), "a", encoding="utf-8") as f:
        f.write(time.strftime("%H:%M:%S ") + line + "\n")

def seen():
    return json.load(open(STATE()))["seen"] if os.path.exists(STATE()) else "E-0"

def one_pass():
    mark = seen()
    batch = [e for e in memory.events() if memory.num(e["id"]) > memory.num(mark)]
    if not any(e["kind"] in ("用户", "读取") for e in batch):
        return False
    log(f"开工：{batch[0]['id']} 到 {batch[-1]['id']}，其中用户 {sum(e['kind'] == '用户' for e in batch)} 条、读取 {sum(e['kind'] == '读取' for e in batch)} 条")
    if any(e["kind"] == "用户" for e in batch):              # 一 五种修订
        consolidate(show=lambda s: log("修订 " + s.strip()), model=MODEL, retry=True)
    gaps = [e for e in batch if e["kind"] == "读取"]
    notes = "\n\n".join(memory.render(memory.load(t)) for t in memory.topics())
    by_id = {e["id"]: e for e in memory.events()}
    users = "\n".join(f"{e['id']}（{e['day']}）：{e['text']}" for e in memory.events() if e["kind"] == "用户")
    ask = ("你是记忆笔记的维护者。请检查下面的笔记，只在确有必要时给出维护动作，只输出 JSON："
           '{"ops": [ {"op": "rewrite", "topic": "话题", "item": 现在的第几条, "text": "改写后的一句", "reason": "补细节|补条件", "sources": ["E-n"]},'
           ' {"op": "resolve", "topic": "话题", "open": 待核对的第几条, "text": "定下来的那一句", "sources": ["E-n"]},'
           ' {"op": "rename", "topic": "话题", "new_name": "新话题名"} ]}\n'
           "要看的：①话题名和现在的内容还贴切吗；②“现在”里有没有缺条件、和别的条目看着打架的；"
           "③“待核对”里有没有已经被后来的原话定下来的（用 resolve）；④下面这些“读取缺口”：回答问题时当前笔记不够、回去读了原话，把原话里缺的那一点补进对应条目。\n"
           "sources 只能填“用户”说的那些记录。没有要改的，就返回空的 ops。\n\n"
           f"【笔记】\n{notes}\n\n【用户说过的原话】\n{users}\n\n【读取缺口】\n"
           + ("\n".join(e["text"] for e in gaps) or "（无）"))
    ops = llm.chat_json([{"role": "user", "content": ask}], model=MODEL).get("ops", [])
    for op in ops:                                           # 二、三 维护
        result = memory.maintain(op)
        log(f"维护 {op.get('op')}｜{op.get('topic')}｜{op.get('new_name') or op.get('text')} {op.get('sources', '')}"
            + ("" if result == "ok" else f"  ✗ 没改：{result}"))
    if not ops:
        log("维护：没有要改的")
    json.dump({"seen": memory.events()[-1]["id"]}, open(STATE(), "w"))
    log(f"收工：看到 {seen()} 为止")
    return True

if __name__ == "__main__":
    if "--watch" not in sys.argv:
        one_pass(); sys.exit()
    log("观测者上岗")
    while True:                                              # 不是每来一条就动：攒一会儿，安静了再整理
        before = len(memory.events())
        time.sleep(float(os.environ.get("OBSERVER_QUIET", "3")))
        if len(memory.events()) == before:
            try:
                one_pass()
            except Exception as e:                           # 后台的活儿出了错：记下来，别死；没推进的边界，下一轮再来
                log(f"出错了，这一轮作废，下一轮重来：{str(e)[:120]}")
