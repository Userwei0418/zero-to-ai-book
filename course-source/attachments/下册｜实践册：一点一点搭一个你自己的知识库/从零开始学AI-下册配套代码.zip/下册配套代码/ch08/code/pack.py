# pack.py：给一个做法包封版。每个文件算一个指纹，连同名字和版本写进 MANIFEST.json
# 用法：python3 pack.py packs/v1/kb-clip
import hashlib, json, os, re, sys

def fingerprint(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()[:12]

def files_of(folder):
    out = {}
    for root, _, names in os.walk(folder):
        for n in names:
            if n not in ("MANIFEST.json", ".installed.json"):
                p = os.path.join(root, n)
                out[os.path.relpath(p, folder)] = fingerprint(p)
    return dict(sorted(out.items()))

def pack(folder):
    head = open(os.path.join(folder, "SKILL.md"), encoding="utf-8").read()
    version = re.search(r"^version:\s*(\S+)", head, re.M).group(1)
    manifest = {"name": os.path.basename(folder.rstrip("/")), "version": version, "files": files_of(folder)}
    json.dump(manifest, open(os.path.join(folder, "MANIFEST.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return manifest

if __name__ == "__main__":
    for f in sys.argv[1:]:
        m = pack(f)
        print(f"{m['name']} {m['version']}：{len(m['files'])} 个文件", m["files"])
