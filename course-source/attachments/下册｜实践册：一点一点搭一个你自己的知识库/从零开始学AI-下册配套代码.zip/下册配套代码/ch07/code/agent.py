# agent.py（第 7 章版）：多了一个参数 rules：这一次交给它的规矩，和规矩出自哪儿
# 一个 Agent。还是第 3 章那个一来一回的循环，外面多了四样东西：
# 一张任务卡，一本流水账，几个刹车，最后一道由程序做的验收
# 用法：python3 agent.py 任务编号 [最多几轮]
import json, os, sys
import llm, toolbox, task
import inbox_tools
from inbox_tools import op_of, lookup

def reconcile(card):
    """开工前先对账：上次开了头、没记结果的那几笔，去知识库那边查一查，再决定"""
    done, pending = task.state(card["id"])
    for op, e in pending.items():
        where = lookup(op)
        if where:
            task.log(card["id"], event="done", op=op, result=f"对账：其实已经办完了，在 {where}")
            print(f"  对账 {op}：开了头没记结果。查了一下，已经写进去了（{where}），记成做完，不重做")
        else:
            task.log(card["id"], event="abandoned", op=op)
            print(f"  对账 {op}：开了头没记结果。查了一下，没写进去，这一件算没开始")
    return task.state(card["id"])[0]

def verify(card):
    """验收不听它说，程序自己数：收件箱里每一件，流水账里都要有“存了”或“跳过”"""
    done, _ = task.state(card["id"])
    missing = [i for i in sorted(os.listdir(inbox_tools.INBOX)) if op_of(i) not in done]
    return missing

def run(card, ask, show=print, rules=None):
    inbox_tools.TASK["id"] = card["id"]
    done = reconcile(card)
    finished = "；".join(f"{op.split(':', 1)[1]}（{e.get('result', e.get('reason', ''))}）" for op, e in done.items())
    system = (f"你在做一项任务。\n目标：{card['goal']}\n怎样算做完：{'；'.join(card['done_when'])}\n"
              + (f"之前已经处理过、不要再碰的：{finished}\n" if finished else "")
              + "每一件都要有个结果：存，或者跳过并说明理由。做完了用一两句话说明你做了什么。")
    if rules:
        text, sources = rules
        system = "这一次要守的规矩：\n\n" + text + "\n\n" + system
        task.log(card["id"], event="rules", sources=sources)              # 记下这一次依据了哪几份规矩
    messages = [{"role": "system", "content": system}, {"role": "user", "content": "开始吧。"}]
    budget, spent0, seen = card["budget"], llm.LEDGER["prompt"] + llm.LEDGER["completion"], {}
    task.log(card["id"], event="start")
    for round_ in range(1, budget["rounds"] + 1):
        used = llm.LEDGER["prompt"] + llm.LEDGER["completion"] - spent0
        if used > budget["tokens"]:                                       # 刹车：花费
            return stop(card, f"花了 {used} 个 token，超过预算 {budget['tokens']}")
        msg = llm.chat_msg(messages, tools=toolbox.specs(card["tools"]))
        notes = msg.get("tool_calls") or []
        if not notes:
            return finish(card, msg.get("content") or "")
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for note in notes:
            name, raw = note["function"]["name"], note["function"]["arguments"] or "{}"
            seen[name + raw] = seen.get(name + raw, 0) + 1
            if seen[name + raw] >= 3:                                     # 刹车：原地打转
                return stop(card, f"同一个动作 {name} 递了第三遍")
            args = json.loads(raw) if raw.strip().startswith("{") else {}
            item = args.get("item", "")
            if name in ("add_clip", "skip_item") and op_of(item) in task.state(card["id"])[0]:
                result = f"{item} 之前已经有结果了，不用再处理"            # 提示里说了别碰，它还是会碰：由程序拦
                show(f"  第 {round_} 轮 {name} {item} → 拦下：{result}")
                messages.append({"role": "tool", "tool_call_id": note["id"], "content": result})
                continue
            if name == "add_clip" and item:
                task.log(card["id"], event="intent", op=op_of(item), title=args.get("title"))   # 动手之前，先记一笔
            result = toolbox.call(note, card["tools"], ask)
            if name == "add_clip" and item:
                if result.startswith(("已存为", "这一笔已经办过了")):
                    task.log(card["id"], event="done", op=op_of(item), result=result)       # 做完了，再记一笔
                else:
                    task.log(card["id"], event="abandoned", op=op_of(item), result=result)
            if name == "skip_item" and item:
                task.log(card["id"], event="skipped", op=op_of(item), reason=args.get("reason"))
            show(f"  第 {round_} 轮 {name} {raw[:50]}{'…' if len(raw) > 50 else ''}\n         → {result[:60].replace(chr(10), ' / ')}")
            messages.append({"role": "tool", "tool_call_id": note["id"], "content": result})
    return stop(card, f"走了 {budget['rounds']} 轮还没做完")                # 刹车：轮数

def stop(card, why):
    task.log(card["id"], event="stopped", why=why)
    return f"（停下了：{why}。流水账都在，重跑同一个任务编号会接着做）"

def finish(card, said):
    missing = verify(card)
    task.log(card["id"], event="finished" if not missing else "claimed", said=said, missing=missing)
    verdict = "验收通过：每一件都有结果" if not missing else f"验收没过：它说做完了，可这几件没有结果：{'、'.join(missing)}"
    return f"{said}\n  【{verdict}】"

def approve(name, args):
    """会写的动作先问人。演示时没人在跟前，就看环境变量 APPROVE"""
    ok = os.environ.get("APPROVE") == "yes"
    print(f"  门：{name} → {args.get('item')}《{args.get('title')}》 {'放行' if ok else '拦下'}")
    return ok

if __name__ == "__main__":
    card = task.new_card(
        sys.argv[1], goal="把收件箱里的剪藏整理进知识库。值得留的，去掉评论和广告存成新笔记；广告、重复的，跳过。",
        done_when=["收件箱里每一件都有结果：存了，或者跳过并写明理由", "存之前先查知识库里有没有类似的"],
        tools=["list_inbox", "read_inbox", "find_notes", "add_clip", "skip_item"], writes=["add_clip"],
        budget={"rounds": 12, "tokens": 40000})
    if len(sys.argv) > 2:
        card["budget"]["rounds"] = int(sys.argv[2])            # 这一次跑最多几轮；卡片本身不改
    print(f"任务卡 {card['id']}：{card['goal']}")
    print(run(card, approve))
    print(llm.bill())
