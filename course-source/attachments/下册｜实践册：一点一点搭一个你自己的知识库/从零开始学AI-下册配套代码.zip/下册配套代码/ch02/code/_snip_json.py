# llm.py 里新加的两样（完整文件见 ch02/code/llm.py）

def chat_json(messages, schema=None, **kw):
    """要它按格式交：交回来必须是一个 JSON 对象。给了 schema，就把格式连同允许的取值一起交给平台去管
    读不出来就报错，不偷偷再问一遍：要不要重来，由调用的人决定"""
    if schema:
        fmt = {"type": "json_schema", "json_schema": {"name": "card", "strict": True, "schema": schema}}
    else:
        fmt = {"type": "json_object"}
    text = chat(messages, response_format=fmt, **kw)
    try:
        data = json.loads(text)
    except ValueError:
        raise NotDone(f"交回来的不是 JSON：{text[:60]!r}") from None
    if not isinstance(data, dict):
        raise NotDone(f"交回来的是 JSON，但不是一个对象：{text[:60]!r}")
    return data

def check(card, rules):
    """逐条验一张卡片。rules 是一张小表：哪些字段必须有、多长、取值只能从哪儿挑。返回问题清单，空的就是合格"""
    problems = []
    for key, rule in rules.items():
        if key not in card:
            problems.append(f"缺了 {key}")
            continue
        value = card[key]
        if rule.get("type") == "text":
            if not isinstance(value, str) or not value.strip():
                problems.append(f"{key} 应该是一段字")
            elif len(value) > rule.get("max", 10**9):
                problems.append(f"{key} 太长了：{len(value)} 字，上限 {rule['max']}")
        if rule.get("type") == "list":
            if not isinstance(value, list):
                problems.append(f"{key} 应该是一个列表")
                continue
            low, high = rule.get("count", (0, 10**9)) if isinstance(rule.get("count"), tuple) else (rule.get("count", 0), rule.get("count", 10**9))
            if not low <= len(value) <= high:
                problems.append(f"{key} 应该 {low}{'' if low == high else '—' + str(high)} 个，交了 {len(value)} 个")
            outside = [v for v in value if "choices" in rule and v not in rule["choices"]]
            if outside:
                problems.append(f"{key} 里有不在词表里的：{'、'.join(map(str, outside))}")
            if len(set(map(str, value))) != len(value):
                problems.append(f"{key} 里有重复的")
    return problems
