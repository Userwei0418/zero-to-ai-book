# draft_card.py：把个人笔记里的一条经验，起草成一张经验卡。起草交给模型，检查交给程序，发不发由主人定
import json
import llm, spaces

ASK = ("把下面这条个人经验，整理成一张可以给别人用的经验卡，只输出 JSON："
       '{"id": "英文短名", "title": "标题", "text": "经验本身，一两句", "scope": "什么情况下适用、什么情况下没验证过", "evidence": "依据：试过几次、什么条件"}\n'
       "要去掉私人信息：人名、“我家”“我这包”这类只有本人知道的东西。\n\n")

def draft(note, feedback=None):
    prompt = ASK + note + (f"\n\n上一稿没通过检查：{feedback}。请改正后重写。" if feedback else "")
    return llm.chat_json([{"role": "user", "content": prompt}])
