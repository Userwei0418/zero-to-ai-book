# try_server.py：接进别的助手之前，先自己当一回客户端，把服务启动起来，新老两种说法各问一遍
# 用法：python3 try_server.py [--allow-write]
import json, os, subprocess, sys

server = subprocess.Popen([sys.executable, "kb_server.py", *sys.argv[1:]], stdin=subprocess.PIPE,
                          stdout=subprocess.PIPE, text=True, env=os.environ)
n = 0
def ask(method, params=None, notify=False):
    global n
    message = {"jsonrpc": "2.0", "method": method, "params": params or {}}
    if not notify:
        n += 1; message["id"] = n
    server.stdin.write(json.dumps(message, ensure_ascii=False) + "\n"); server.stdin.flush()
    if notify:
        return None
    reply = json.loads(server.stdout.readline())
    return reply.get("result", reply.get("error"))

def short(x):
    s = json.dumps(x, ensure_ascii=False)
    return s if len(s) < 140 else s[:140] + "…"

print("【老客户端的说法】")
print("initialize      →", short(ask("initialize", {"protocolVersion": "2025-06-18", "capabilities": {},
                                                      "clientInfo": {"name": "try", "version": "0"}})))
ask("notifications/initialized", notify=True)
tools = ask("tools/list")["tools"]
print("tools/list      →", [(t["name"], "只读" if t["annotations"]["readOnlyHint"] else "会写") for t in tools])
print("tools/call      →", short(ask("tools/call", {"name": "search_notes", "arguments": {"query": "切块 重叠"}})))

print("\n【新客户端的说法】")
meta = {"_meta": {"io.modelcontextprotocol/protocolVersion": "2026-07-28",
                  "io.modelcontextprotocol/clientCapabilities": {}}}
print("server/discover →", short(ask("server/discover", meta)))
print("tools/call      →", short(ask("tools/call", {**meta, "name": "read_note", "arguments": {"name": "生活-番茄炒蛋.md"}})))

print("\n【坏请求】")
print("读文件夹外面    →", short(ask("tools/call", {"name": "read_note", "arguments": {"name": "../index.md"}})))
print("没开的工具      →", short(ask("tools/call", {"name": "add_clip", "arguments": {"title": "t", "text": "x", "source": "s"}})))
print("没有的方法      →", short(ask("resources/list")))
server.stdin.close(); server.wait()
print("\n服务正常退出，退出码", server.returncode)
