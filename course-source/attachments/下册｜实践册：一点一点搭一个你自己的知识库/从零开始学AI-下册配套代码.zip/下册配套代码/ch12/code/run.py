# run.py：交一件事给后台的小团队；交完你照样干别的，时不时看一眼进度
import os, sys, time
import llm, team

workers = int(sys.argv[1]) if len(sys.argv) > 1 else 3
rid = sys.argv[2] if len(sys.argv) > 2 else "r-001"
print("交：", team.submit(rid, workers))
print("再交一次同一个编号：", team.submit(rid, workers))
while team.TASKS[rid].is_alive():
    time.sleep(8)
    print("看一眼：", team.status(rid))
team.TASKS[rid].join()
print("\n工作记录：")
for line in __import__("json").load(open(f"work/{rid}.json", encoding="utf-8"))["log"]:
    print(" ", line)
print("\n结果：", team.status(rid))
print(llm.bill())
