# ask_week3.py：第三周，问它几个问题。最后一个问题之前，你又说了一句，还没来得及整理
import llm, memory
from recall import recall

for q in ["读书会上我哪天分享？", "为什么改日子了？", "下次周会是周几？", "冷萃要泡多久？"]:
    print(f"【{q}】"); print("答：", recall(q)); print()
print(memory.record("京都改成明年 1 月去了，12 月机票太贵。", day="11-13"), "11-13 京都改成明年 1 月去了，12 月机票太贵。（还没整理）\n")
q = "京都什么时候去？"
print(f"【{q}】"); print("答：", recall(q))
print(llm.bill())
