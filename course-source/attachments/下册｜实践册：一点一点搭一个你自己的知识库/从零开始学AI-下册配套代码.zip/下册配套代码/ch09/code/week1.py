# week1.py：第一周你随口说过的几句话，记下来，整理一次
import memory
from consolidate import consolidate

for day, text in [
    ("11-02", "我最近在读《原子习惯》。两分钟规则就是每次只做两分钟，做完就停。"),
    ("11-02", "我每天早上 7:30 写三行日记。"),
    ("11-03", "读书会上我负责 11 月 9 日分享《原子习惯》，十分钟。"),
    ("11-04", "冷萃照论坛说的，泡 12 小时。"),
    ("11-05", "京都打算 12 月初去，住五晚。"),
]:
    print(memory.record(text, day=day), day, text)
print("\n整理：")
consolidate()
