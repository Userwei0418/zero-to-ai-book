# team.py：几个助手一起干活。分工是这样的：
#   调度（router）：收下请求，按收件箱一件一件拆成小活，派给干活的；它自己不干具体的活
#   干活的（worker）：一人一件，在自己的草稿目录里写一份“提案”：存还是跳、标题、正文。它碰不到知识库
#   审核的（reviewer）：用另一个模型、另一套提示，对照原文和规矩，逐份看提案
#   落笔的（merger）：只有它能写知识库，一份一份落，同一时刻只有一个人在写
# 请求带编号：同一个编号再提交一次，拿回的是同一个任务，不会再跑一遍
# 用法见 run.py
import hashlib, json, os, threading, time, uuid
from concurrent.futures import ThreadPoolExecutor
import llm
from find import find, load

KB, INBOX, WORK = os.environ.get("KB_DIR", "kb"), "inbox", "work"
RULES = open("rules.md", encoding="utf-8").read()
REVIEW_MODEL = os.environ.get("REVIEW_MODEL", "deepseek-v4.1-flash")
LOCK = threading.Lock()                                       # 写知识库的那把锁：同一时刻只有一个人在写
TASKS = {}

def save_task(t):
    os.makedirs(WORK, exist_ok=True)
    json.dump(t, open(os.path.join(WORK, t["request_id"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---------- 调度 ----------
def submit(request_id, workers=3):
    """交一件事，马上返回。真正的活在后台跑。同一个 request_id，只会有一个任务"""
    path = os.path.join(WORK, request_id + ".json")
    if os.path.exists(path):
        return json.load(open(path, encoding="utf-8"))["status"] + "（这个请求之前交过了，没有再跑一遍）"
    items = sorted(os.listdir(INBOX))
    t = {"request_id": request_id, "status": "进行中", "items": {i: "排队" for i in items}, "log": [], "started": time.time()}
    save_task(t)
    TASKS[request_id] = threading.Thread(target=_run, args=(t, workers))
    TASKS[request_id].start()
    return f"收下了，{len(items)} 件，{workers} 个助手在后台干"

def status(request_id):
    t = json.load(open(os.path.join(WORK, request_id + ".json"), encoding="utf-8"))
    return t["status"] + "｜" + "，".join(f"{i}:{s}" for i, s in t["items"].items())

def _note(t, item, state, line=None):
    with LOCK:
        t["items"][item] = state
        if line:
            t["log"].append(f"{time.time() - t['started']:5.1f}s  {line}")
        save_task(t)

def _run(t, workers):
    def one(item):
        try:
            _one(item)
        except Exception as e:                                # 后台线程里的错，不接住就悄无声息地没了
            _note(t, item, f"出错：{str(e)[:60]}", f"{item}：出错了——{str(e)[:80]}")
    def _one(item):
        clip = open(os.path.join(INBOX, item), encoding="utf-8").read()
        _note(t, item, "起草中")
        p = worker(item, clip)
        _note(t, item, "审核中", f"{item}：提案 {p.get('decision')}《{p.get('title', '')}》")
        v = reviewer(p, clip)
        if not v.get("ok"):                                   # 退回一次，带着理由
            _note(t, item, "返工中", f"{item}：审核退回——{'；'.join(v.get('problems', []))}")
            p = worker(item, clip, feedback=v.get("problems"))
            v = reviewer(p, clip)
        if not v.get("ok"):
            _note(t, item, "等人看", f"{item}：返工后还是没过——{'；'.join(v.get('problems', []))}")
            return
        _note(t, item, "待落笔", f"{item}：审核通过")
        _note(t, item, merger(t["request_id"], item, p), None)
    with ThreadPoolExecutor(workers) as pool:
        list(pool.map(one, list(t["items"])))
    bad = [i for i, s in t["items"].items() if s.startswith(("出错", "等人看"))]
    t["status"] = f"完成，用了 {time.time() - t['started']:.0f} 秒" + (f"，{len(bad)} 件要人看" if bad else "")
    save_task(t)

# ---------- 干活的 ----------
def worker(item, clip, feedback=None):
    """一件剪藏，一份提案。它只读知识库，不写"""
    related = "\n".join(f"{c['file']}：{c['text']}（相似度 {s}）" for c, s in find(clip[:300], load(KB), k=3))
    ask = (RULES + "\n\n下面是一件剪藏，和知识库里最像的几条。请决定存还是跳，只输出 JSON："
           '{"decision": "存|跳", "title": "十来个字", "text": "存的话，整理好的正文", "reason": "跳的话，理由"}\n\n'
           f"【剪藏】\n{clip}\n\n【知识库里最像的】\n{related}"
           + (f"\n\n【上一稿被审核退回，理由】\n{'；'.join(feedback)}" if feedback else ""))
    p = llm.chat_json([{"role": "user", "content": ask}])
    p["item"] = item
    p["clip_sha"] = hashlib.sha1(clip.encode("utf-8")).hexdigest()[:12]
    first = clip.strip().splitlines()[0]
    p["source"] = first[3:].strip() if first.startswith("来源：") else None    # 来源由程序从原文第一行取，不交给模型
    os.makedirs(os.path.join(WORK, "drafts"), exist_ok=True)
    json.dump(p, open(os.path.join(WORK, "drafts", item + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return p

# ---------- 审核的 ----------
def reviewer(p, clip):
    """另一个模型、另一套提示。它不知道干活的怎么想的，只看原文、规矩和提案"""
    related = "\n".join(f"{c['file']}：{c['text']}" for c, _ in find(clip[:300], load(KB), k=3))
    ask = ("你是审核。对照规矩、原文和知识库里最像的几条，检查这份提案有没有问题，只输出 JSON："
           '{"ok": true 或 false, "problems": ["问题，一条一句"]}\n'
           "要查的：该跳的有没有存、该存的有没有跳；正文里有没有留着评论、广告、联系方式；有没有原文里没有的内容。\n\n"
           f"【规矩】\n{RULES}\n\n【原文】\n{clip}\n\n【知识库里最像的】\n{related}\n\n【提案】\n{json.dumps(p, ensure_ascii=False)}")
    return llm.chat_json([{"role": "user", "content": ask}], model=REVIEW_MODEL)

# ---------- 落笔的 ----------
def already_there(text, threshold=0.93):
    """拿要写的正文，和知识库里此刻的每一篇比一比。现读现算，不用之前建好的索引"""
    names = [n for n in os.listdir(KB) if n.endswith(".md") and n != "index.md"]
    bodies = [open(os.path.join(KB, n), encoding="utf-8").read().split("\n\n", 1)[-1] for n in names]
    texts = [text] + bodies
    vecs = [v for i in range(0, len(texts), 16) for v in llm.embed(texts[i:i + 16])]   # 一次最多 16 段：多了平台不收
    q = vecs[0]
    cos = lambda a, b: sum(x * y for x, y in zip(a, b)) / ((sum(x * x for x in a) * sum(y * y for y in b)) ** 0.5)
    best = max(zip(names, vecs[1:]), key=lambda nv: cos(q, nv[1]))
    return best[0] if cos(q, best[1]) >= threshold else None

def merger(request_id, item, p):
    """只有它写知识库。一次一份；编号是 请求编号:文件名，重来不会写两遍；同名的不覆盖"""
    with LOCK:
        ops_path = os.path.join(KB, ".ops.json")
        ops = json.load(open(ops_path, encoding="utf-8")) if os.path.exists(ops_path) else {}
        op = f"{request_id}:{item}"
        if op in ops:
            return f"已经落过了：{ops[op]}"
        clip_key = "原文:" + p["clip_sha"]                    # 原文的指纹：同一段原文，不管谁、哪一次整理，都只落一篇
        same = None if p.get("decision") != "存" else (ops.get(clip_key) or already_there(p["text"]))
        if p.get("decision") != "存":
            ops[op] = f"跳过：{p.get('reason', '')}"
        elif same:                                            # 落笔前看的是此刻的知识库，不是干活的人拿到的那份快照
            ops[op] = f"跳过：落笔时发现知识库里已经有了（{same}）"
        else:
            name = "剪藏-" + "".join(ch for ch in p["title"] if ch not in '\\/:*?"<>| ')[:20] + ".md"
            if os.path.exists(os.path.join(KB, name)):
                name = name[:-3] + "-" + uuid.uuid4().hex[:4] + ".md"     # 同名不覆盖
            source = p.get("source") or "未注明"
            open(os.path.join(KB, name), "w", encoding="utf-8").write(f"# 剪藏：{p['title']}\n来源：{source}\n\n{p['text'].strip()}\n")
            ops[op] = name
            ops[clip_key] = name
        json.dump(ops, open(ops_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return "落笔：" + ops[op]
