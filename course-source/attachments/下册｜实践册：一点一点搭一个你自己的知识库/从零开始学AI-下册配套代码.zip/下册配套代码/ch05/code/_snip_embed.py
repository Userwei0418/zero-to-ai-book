# llm.py 里新加的两样（完整文件见 ch05/code/llm.py）

def embed(texts, model=None):
    """把一批字变成一批向量：每段字一串 1024 个数。意思相近的字，数也相近"""
    began = time.time()
    body = {"model": model or os.environ.get("EMBED_MODEL", "qwen3.7-text-embedding"), "input": texts}
    with _post(body, path="/embeddings") as resp:
        data = json.loads(resp.read())
    _book({"prompt_tokens": data.get("usage", {}).get("prompt_tokens", 0)}, began)
    return [d["embedding"] for d in sorted(data["data"], key=lambda d: d["index"])]

def rerank(query, documents, model=None):
    """拿问题把一批候选从头读一遍，打一个“有多相关”的分。比向量慢，但准"""
    began = time.time()
    body = {"model": model or os.environ.get("RERANK_MODEL", "qwen3.7-text-rerank"), "query": query, "documents": documents}
    with _post(body, path="/rerank") as resp:
        data = json.loads(resp.read())
    _book({"prompt_tokens": data.get("usage", {}).get("prompt_tokens", 0)}, began)
    return [(r["index"], r["relevance_score"]) for r in data["results"]]
