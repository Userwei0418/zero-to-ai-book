# llm.py 里新加的一段
class NotDone(LLMError):
    """它回了话，但这一次不能算完成"""

def done(choice, usage):
    """什么才算一次调用完成：说完了（stop），而且真有内容。写满了、被拦了、递了纸条，都不算"""
    why = choice.get("finish_reason")
    text = (choice.get("message") or {}).get("content") or ""
    if usage is None or "completion_tokens" not in (usage or {}):
        LEDGER["unknown"] = LEDGER.get("unknown", 0) + 1            # 账不全：记下“不知道”，不当成 0
    if why == "stop" and text.strip():
        return
    raise NotDone({"length": f"写到上限被掐断了，只有前半截：{text[-30:]!r}",
                   "content_filter": "被平台的内容过滤拦下了",
                   "tool_calls": "它没说话，递来了一张要用工具的纸条"}.get(why, f"停下的原因是 {why!r}，内容{'为空' if not text.strip() else '不完整'}"))
