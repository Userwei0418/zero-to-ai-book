# two_models.py：同一件事交给两个模型。只改一个参数，看快慢、看花费、看写出来的东西
import llm

NOTE = open("../../kb/notes/剪藏-RAG入门.md", encoding="utf-8").read()
ASK = [{"role": "user", "content": "用不超过 40 个字，概括下面这篇笔记讲了什么：\n\n" + NOTE}]

for model in ("senseaudio-s2-flash", "deepseek-v4.1-flash"):
    before = dict(llm.LEDGER)
    answer = llm.chat(ASK, model=model)
    used = {k: llm.LEDGER[k] - before[k] for k in llm.LEDGER}
    print(f"【{model}】{used['seconds']:.1f} 秒，读 {used['prompt']} 写 {used['completion']} 个 token")
    print(f"  {answer.strip()}\n")
