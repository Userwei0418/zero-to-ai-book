# schema_demo.py：把格式和词表交给平台去管（json_schema），看看它管住了什么、没管住什么
import sys
import llm
from rules import TOPICS, RULES

SCHEMA = {"type": "object", "additionalProperties": False, "required": ["summary", "topics"],
          "properties": {"summary": {"type": "string", "maxLength": 30},
                         "topics": {"type": "array", "minItems": 2, "maxItems": 2, "uniqueItems": True,
                                    "items": {"type": "string", "enum": list(TOPICS)}}}}

text = open("../../kb/notes/剪藏-番茄工作法.md", encoding="utf-8").read()
for model in sys.argv[1:]:
    try:
        card = llm.chat_json([{"role": "user", "content": "给这篇笔记写摘要、挑话题\n\n" + text}], schema=SCHEMA, model=model, timeout=60)
    except llm.LLMError as e:
        print(f"{model}：{e}")
        continue
    print(f"{model}：{card}")
    print(f"    自己再验一遍：{llm.check(card, RULES) or '合格'}")
