# vocab_ask.py：带词表的那段提示，vocab.py、evaluate.py、index_kb.py 共用
from rules import TOPICS

ASK = ("下面是我知识库里的一篇笔记。请用 JSON 回答，格式是 {\"summary\": \"一句话摘要，不超过 30 字\", \"topics\": [一到两个话题]}。\n"
       "话题只能从下面这张词表里挑一到两个真正相关的，不要自己造；只有一个相关就只写一个：\n"
       + "\n".join(f"- {k}：{v}" for k, v in TOPICS.items()) + "\n\n")
