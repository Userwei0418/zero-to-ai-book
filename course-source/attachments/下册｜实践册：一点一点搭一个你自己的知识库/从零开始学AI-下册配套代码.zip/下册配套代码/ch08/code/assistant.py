# assistant.py：带着做法包目录的小助手。目录每次都带；正文和附件，用到才取
# 用法：python3 assistant.py "你要它做的事"
import sys
import llm, toolbox
import kb_tools, semantic_tools, skills

TOOLS = ["use_skill", "read_skill_file", "find_notes", "search_notes", "read_note", "add_clip"]

def system():
    return ("你是我的知识库助手。你手边有这些做法包，事情对得上哪一个，先用 use_skill 取出正文，照着做；"
            "都对不上，就直接回答：\n" + skills.catalog())

def ask(request, show=print, approve=lambda n, a: True):
    messages = [{"role": "system", "content": system()}, {"role": "user", "content": request}]
    for _ in range(10):
        msg = llm.chat_msg(messages, tools=toolbox.specs(TOOLS))
        notes = msg.get("tool_calls") or []
        if not notes:
            return msg.get("content") or ""
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for note in notes:
            result = toolbox.call(note, TOOLS, approve)
            show(f"  {note['function']['name']} {note['function']['arguments'][:60]}")
            messages.append({"role": "tool", "tool_call_id": note["id"], "content": result})
    return "（十轮还没做完）"

if __name__ == "__main__":
    print(f"目录 {len(skills.catalog())} 字：\n{skills.catalog()}\n")
    print("答：", ask(sys.argv[1]))
    print(llm.bill())
