# answer.py：先找，再答。答案里每一句都要标出处 [文件:行]；交回来以后，程序一条一条核对出处
# 用法：python3 answer.py 笔记文件夹 "问题"
import hashlib, os, re, sys
from . import llm
from .find import find, load

def answer(question, folder, k=4):
    hits = find(question, load(folder), k=k, rerank=True)
    shown = {f"{c['file']}:{c['line']}": c for c, _ in hits}
    excerpts = "\n".join(f"[{a}] {c['text']}" for a, c in shown.items())
    reply = llm.chat([{"role": "user", "content":
        "只根据下面这几条摘录回答问题。每句话后面用方括号标出处，照抄摘录前面的 [文件:行]。"
        "摘录里没有的，就说笔记里没写，不要补充。\n\n摘录：\n" + excerpts + "\n\n问题：" + question}])
    return reply, shown

def check(reply, shown, folder):
    """一条一条核对出处：是不是给它看过的那几条？原文这一行还是不是当初那一行？"""
    problems = []
    cited = re.findall(r"\[([^\[\]]+?\.md:\d+)\]", reply)
    if not cited and "没写" not in reply:
        problems.append("一个出处都没标")
    for a in dict.fromkeys(cited):
        if a not in shown:
            problems.append(f"{a}：没给它看过这一条，出处是它自己写的")
            continue
        c = shown[a]
        path = os.path.join(folder, c["file"])
        lines = open(path, encoding="utf-8").read().splitlines() if os.path.exists(path) else []
        now = lines[c["line"] - 1] if len(lines) >= c["line"] else ""
        if hashlib.sha1(now.encode("utf-8")).hexdigest()[:10] != c["hash"]:
            problems.append(f"{a}：原文这一行建索引以后改过了，现在是“{now.strip()}”")
    return problems

if __name__ == "__main__":
    reply, shown = answer(sys.argv[2], sys.argv[1])
    print("答：", reply)
    if not re.search(r"\.md:\d+\]", reply):
        print("核对：没有标出处。它说的是笔记里没写，这句不用核")
    else:
        print("核对：", "；".join(check(reply, shown, sys.argv[1])) or "每条出处都对得上")
    print(llm.bill())
