# 剪藏：Python 虚拟环境
来源：官方文档摘录，2026-06-20
- 建：python3 -m venv .venv
- 进：source .venv/bin/activate
- 一个项目一个环境，依赖写进 requirements.txt。
