# ask.py：问知识库一个问题。它递纸条，我们去办，把结果交回去，直到它给出答案
# 用法：python3 ask.py "你的问题"
import sys
import llm, toolbox
import kb_tools

TOOLS = ["search_notes", "read_note"]               # 这一次只交给它两样只读的
SYSTEM = ("你是我的知识库助手。回答前先用工具在我的笔记里找；找到了，要说出出自哪篇笔记的第几行。"
          "笔记里没有的，就说没找到，不要自己编。")

def ask_kb(question, tools=TOOLS, ask=lambda name, args: False, rounds=6, show=print):
    messages = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": question}]
    for _ in range(rounds):
        msg = llm.chat_msg(messages, tools=toolbox.specs(tools))
        notes = msg.get("tool_calls") or []
        if not notes:
            return msg.get("content") or ""
        messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
        for note in notes:
            result = toolbox.call(note, tools, ask)
            show(f"  纸条：{note['function']['name']} {note['function']['arguments']}")
            show("  办完：" + result.replace("\n", "\n        ")[:300])
            messages.append({"role": "tool", "tool_call_id": note["id"], "content": result})
    return f"（来回了 {rounds} 轮还没答完，先停在这儿）"

if __name__ == "__main__":
    print("答：", ask_kb(sys.argv[1]))
    print(llm.bill())
