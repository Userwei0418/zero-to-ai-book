# compare.py：同一份考卷，三种找法。看第一条是不是那一行，前三条里有没有那一行
# ① 关键词：让模型想关键词，交给第 3 章的 search_notes  ② 向量  ③ 向量粗筛 + 重排
import json, os, re, sys
import llm, kb_tools
from find import find, load

folder = sys.argv[1]
kb_tools.KB = folder
chunks = load(folder)
qs = json.load(open("questions.json", encoding="utf-8"))

def by_keywords(q):
    words = llm.chat([{"role": "user", "content": f"我要在笔记里按关键词搜这个问题，给我两三个关键词，空格隔开，只输出关键词：{q}"}]).strip()
    hits = re.findall(r"^(\S+\.md) 第 (\d+) 行", kb_tools.search_notes(words), re.M)
    return [(f, int(n)) for f, n in hits[:3]], words

score = {"关键词": [0, 0], "向量": [0, 0], "向量+重排": [0, 0]}     # [第一条就是, 前三条里有]
for item in qs:
    want = lambda got: any(f == item["file"] and n in item["lines"] for f, n in got)
    kw, words = by_keywords(item["q"])
    vec = [(c["file"], c["line"]) for c, _ in find(item["q"], chunks)]
    rr = [(c["file"], c["line"]) for c, _ in find(item["q"], chunks, rerank=True)]
    marks = []
    for name, got in (("关键词", kw), ("向量", vec), ("向量+重排", rr)):
        top1, top3 = want(got[:1]), want(got)
        score[name][0] += top1; score[name][1] += top3
        marks.append("◎" if top1 else "✓" if top3 else "✗")
    print(f"{' '.join(marks)}  {item['q']}   （关键词：{words}）")
print("◎ 第一条就是  ✓ 前三条里有  ✗ 没找到")
for k, (a, b) in score.items():
    print(f"  {k}：第一条就是 {a}/{len(qs)}，前三条里有 {b}/{len(qs)}")
print(llm.bill())
