# accept.py：知识库的验收。一份考卷，每道题跑几遍，每一遍留下证据
# 能用程序判的，程序判；只有“答在点子上没有”这种，才请另一个模型当判官，而且判官先要校准过（见 calibrate.py）
# 用法：python3 accept.py 标签 [每题跑几遍]      报告存成 report-标签.json，可以拿两份报告比（diff.py）
import json, os, re, sys, time
import llm, team
from find import find, load
from answer import answer, check

KB = os.environ.get("KB_DIR", "kb")
JUDGE = os.environ.get("JUDGE_MODEL", "deepseek-v4.1-flash")
CONTACT = re.compile(r"[\w.]+@[\w.]+|1\d{2}\s?\d{4}\s?\d{4}|微信")

def judge(question, reply, must):
    v = llm.chat_json([{"role": "user", "content":
        "你是判官。只看这一条标准，判这个回答过没过，只输出 JSON：{\"pass\": true 或 false, \"why\": \"一句话\"}\n"
        f"标准：{must}\n问题：{question}\n回答：{reply}"}], model=JUDGE)
    return bool(v.get("pass")), v.get("why", "")

def run_case(c):
    """跑一遍，交回（过没过，证据）。证据是给人看的：凭什么说它过了，或者凭什么说它没过"""
    if c["kind"] == "找":
        top = find(c["q"], load(KB), k=1, rerank=True)[0][0]
        got = f"{top['file']}:{top['line']}"
        return got == c["want"], f"第一条是 {got}"
    if c["kind"] == "答":
        reply, shown = answer(c["q"], KB)
        cited = re.findall(r"\[([^\[\]]+?\.md:\d+)\]", reply)
        if c["want"]:
            problems = ([] if c["want"] in cited else [f"没标到 {c['want']}"]) + check(reply, shown, KB)
        else:
            problems = [f"不该有出处，却标了 {cited}"] if cited else []
        ok_judge, why = judge(c["q"], reply, c["must"])
        prog = "程序：" + ("；".join(problems) if problems else "出处都对")      # 证据要写全：程序为什么判、判官为什么判
        return not problems and ok_judge, f"{prog}｜判官{'过' if ok_judge else '不过'}：{why}"
    if c["kind"] == "藏":
        clip = open(os.path.join("clips", c["clip"]), encoding="utf-8").read()
        p = team.worker(c["clip"], clip)
        text = p.get("text", "") or ""
        problems = []
        if p.get("decision") != c["decision"]:
            problems.append(f"该{c['decision']}却{p.get('decision')}")
        if c.get("related") and "相关：" not in text:
            problems.append("没写“相关：”")
        if c.get("no_contact") and CONTACT.search(text):
            problems.append(f"正文里留着联系方式：{CONTACT.search(text).group()}")
        return not problems, "；".join(problems) or f"{p.get('decision')}《{p.get('title', '')}》"

def main(tag, n):
    cases = json.load(open("cases.json", encoding="utf-8"))
    report, ran = {"tag": tag, "model": os.environ.get("LLM_MODEL"), "when": time.strftime("%Y-%m-%d %H:%M"), "cases": {}}, 0
    for c in cases:
        runs = []
        for _ in range(n):
            try:
                ok, ev = run_case(c)
            except Exception as e:                            # 出错算没过，证据写错误
                ok, ev = False, f"出错：{str(e)[:60]}"
            runs.append({"ok": ok, "evidence": ev}); ran += 1
        k = sum(r["ok"] for r in runs)
        verdict = "过" if k == n else ("摇摆" if k else "没过")
        report["cases"][c["id"]] = {"passed": k, "runs": n, "verdict": verdict, "evidence": [r["evidence"] for r in runs]}
        bad = next((r["evidence"] for r in runs if not r["ok"]), runs[0]["evidence"])
        print(f"{c['id']}  {k}/{n}  {verdict:3}  {bad[:70]}", flush=True)
    passed = sum(v["verdict"] == "过" for v in report["cases"].values())
    print(f"\n跑完了：{len(cases)} 道题 × {n} 遍 = {ran} 遍，一遍不少")
    print(f"验收：{passed}/{len(cases)} 道题每一遍都过；摇摆 {sum(v['verdict'] == '摇摆' for v in report['cases'].values())} 道；没过 {sum(v['verdict'] == '没过' for v in report['cases'].values())} 道")
    json.dump(report, open(f"report-{tag}.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(llm.bill())

if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 3)
