# life.py：几个空间，几个人，一张经验卡的发布、采纳和撤回
import json
import llm, spaces
from bot import ask
from draft_card import draft

spaces.make_space("小满", owner="小满", members=[], notes=[
    {"text": "冷萃：深烘豆泡 8 小时正好，12 小时太苦；浅烘豆泡 12 小时刚好。我这包是楼下店里买的。", "src": "E-7 E-14"},
    {"text": "体检约在 11 月 20 日上午，要空腹。", "src": "E-16"}])
spaces.make_space("读书会", owner="小满", members=["阿青", "老周"], notes=[
    {"text": "小满 11 月 16 日分享《原子习惯》，十分钟（9 号场地被占，改期）。", "src": "E-6"},
    {"text": "下个月读《置身事内》的续篇，阿青找书。", "src": "会议-读书会1019.md:3"}])

def q(who, room, question):
    print(f"【{who} 在“{room}”里问】{question}")
    print(f"  答：{ask(who, room, question)}\n")

print("① 读书会里的事，读书会的人读得到；小满的私事，读不到")
q("阿青", "读书会", "小满哪天分享？")
q("阿青", "读书会", "小满的冷萃是怎么泡的？体检约在哪天？")

print("② 小满把冷萃那条经验整理成经验卡")
note = spaces.space("小满")["notes"][0]["text"]
card = draft(note)
print("  第一稿：", json.dumps(card, ensure_ascii=False))
problems = spaces.check_card(card)
print("  程序检查：", "；".join(problems) or "通过")
if problems:
    card = draft(note, "；".join(problems))
    print("  第二稿：", json.dumps(card, ensure_ascii=False))
    print("  程序检查：", "；".join(spaces.check_card(card)) or "通过")
print(" ", spaces.publish("小满", card, approved=False), "（主人还没点头）")
print(" ", spaces.publish("小满", card, approved=True), "（主人点了头）\n")
cid = card["id"]

print("③ 再问一次")
q("阿青", "读书会", "小满的冷萃是怎么泡的？")

print("④ 读书会把这张卡采纳进来")
print(" ", spaces.adopt("阿青", "读书会", cid))
print("  读书会现在的笔记：\n" + spaces.read_space("阿青", "读书会") + "\n")

print("⑤ 小满发现深烘那一条只对那一家店的豆子成立，撤回了这张卡")
print(" ", spaces.withdraw("小满", cid, "只在一种豆子上试过，不够普遍"))
q("阿青", "读书会", "冷萃要泡多久？")

print("⑥ 老周退出读书会")
print(" ", spaces.remove_member("小满", "读书会", "老周"))
q("老周", "读书会", "下个月读什么书？")

print("⑦ 阿青请小满的助手改分享日期，再通知大家")
q("阿青", "读书会", "@小满的助手 帮我把小满的分享改到 11 月 23 日，再在群里通知大家一声。")
print("  小满的待办：", json.dumps(json.load(open("spaces/todo.json", encoding="utf-8")), ensure_ascii=False))
print(" ", spaces.decide("小满", 0, yes=True), "\n")

print("⑧ 审计（最后几条）")
for line in open("spaces/audit.jsonl", encoding="utf-8").read().splitlines()[-6:]:
    print(" ", line)
print(llm.bill())
