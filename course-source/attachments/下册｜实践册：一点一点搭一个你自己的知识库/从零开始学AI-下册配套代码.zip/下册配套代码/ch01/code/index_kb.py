# index_kb.py：这一章的成品。给知识库里的每一篇笔记写一行目录：标题、一句话摘要、三个标签，存成 index.md
# 用法：python3 index_kb.py 笔记文件夹
import os, sys
import llm

ASK = ("下面是我知识库里的一篇笔记。请只输出一行，格式是：一句话摘要（不超过 30 字）｜标签1，标签2，标签3\n"
       "不要输出别的。\n\n")

folder = sys.argv[1]
rows, odd = [], []
for name in sorted(os.listdir(folder)):
    if not name.endswith(".md") or name == "index.md":
        continue
    text = open(os.path.join(folder, name), encoding="utf-8").read()
    title = text.splitlines()[0].lstrip("# ").strip()
    line = llm.chat([{"role": "user", "content": ASK + text}]).strip().splitlines()[0]
    if line.count("｜") != 1:                                         # 不合格式的，先记下来，不硬塞进目录
        odd.append(f"{name}：{line}")
        continue
    summary, tags = (part.strip() for part in line.split("｜"))
    rows.append(f"| [{title}]({name}) | {summary} | {tags} |")

open(os.path.join(folder, "index.md"), "w", encoding="utf-8").write(
    "# 我的知识库目录\n\n| 笔记 | 一句话 | 标签 |\n|-|-|-|\n" + "\n".join(rows) + "\n")
print(f"写好了 index.md：{len(rows)} 篇进了目录" + (f"，{len(odd)} 篇格式不对没进：" if odd else ""))
for o in odd:
    print("  ", o)
print(llm.bill(price_in=1.0, price_out=4.0), "（价格是举例：每百万 token 读 1 元、写 4 元）")
