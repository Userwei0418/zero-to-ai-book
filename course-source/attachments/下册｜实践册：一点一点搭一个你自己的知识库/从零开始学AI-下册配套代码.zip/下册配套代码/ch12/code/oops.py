# oops.py：三份故意做坏的提案，看审核拦不拦得住
import json
import llm, team

tea = open("inbox/tea.txt", encoding="utf-8").read()
git = open("inbox/git-branch.txt", encoding="utf-8").read()
bad = [
    ("留着联系方式", tea, {"decision": "存", "title": "冷泡茶做法", "text": "绿茶 5 克，冷水 500 毫升，冰箱泡 6 到 8 小时。乌龙泡 10 小时左右。买茶加微信 tea_lover_2026。"}),
    ("多了原文没有的", tea, {"decision": "存", "title": "冷泡茶做法", "text": "绿茶 5 克，冷水 500 毫升，冰箱泡 6 到 8 小时。乌龙泡 10 小时左右。红茶不适合冷泡，容易发酸。"}),
    ("该存的当广告跳了", git, {"decision": "跳", "title": "Git 分支", "reason": "广告：文末有训练营报名"}),
]
for name, clip, p in bad:
    v = team.reviewer(p, clip)
    print(f"【{name}】{'拦住了' if not v.get('ok') else '没拦住'}：{'；'.join(v.get('problems', [])) or '（没提问题）'}")
print(llm.bill())
