# check_skill.py：装进别的助手之前，先按通行的规矩查一遍。用法：SKILLS_DIR=my/skills python3 check_skill.py kb-clip
import os, re, sys
from skills import read_card

folder = sys.argv[1].rstrip("/")
head, body = read_card(os.path.basename(folder))
problems = []
name, desc = head.get("name", ""), head.get("description", "")
if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name) or len(name) > 64:
    problems.append("name 只能用小写字母、数字和连字符，不超过 64 个字符")
if name != os.path.basename(folder):
    problems.append(f"name（{name}）要和文件夹名（{os.path.basename(folder)}）一样")
if not desc or len(desc) > 1024:
    problems.append("description 不能空，也不要超过 1024 个字符")
if "使用" not in desc and "when" not in desc.lower():
    problems.append("description 里最好写明“什么时候用”，助手是靠这一句决定要不要取它的")
print(f"{name}：{len(desc)} 字的说明，{len(body)} 字的正文")
print("\n".join("  ✗ " + p for p in problems) or "  ✓ 合规矩")
