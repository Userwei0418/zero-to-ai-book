# memory.py 末尾加的（完整文件见 ch10/code/memory.py）
# ---------- 第 10 章：维护动作。来源可以是任何一条“用户”记录，但不能是整理、读取、回答这些系统自己留下的 ----------
def _check_sources(src):
    by_id = {e["id"]: e for e in events()}
    if not src:
        return "没有来源"
    for s in src:
        if s not in by_id:
            return f"来源 {s} 不存在"
        if by_id[s]["kind"] != "用户":
            return f"来源 {s} 是“{by_id[s]['kind']}”记录，不是用户说的，不能当证据"
    return None

def maintain(op):
    kind, topic = op.get("op"), op.get("topic")
    if topic not in topics():
        return f"没有 {topic} 这个话题"
    note = load(topic)
    if kind == "rename":                                     # 改话题名：旧名字记进别名，按旧名也找得到
        new = op.get("new_name", "").strip()
        if not new or new in topics():
            return "新名字是空的，或者已经有了"
        note["aliases"] = note.get("aliases", []) + [topic]
        note["topic"] = new
        save(note)
        for ext in (".json", ".md"):
            os.remove(os.path.join(NOTES(), topic + ext))
        return "ok"
    bad = _check_sources(op.get("sources") or [])
    if bad:
        return bad
    if kind == "rewrite":                                    # 补细节、补条件：旧的写法挪到“以前”，写明为什么改
        k = op.get("item")
        if not isinstance(k, int) or not 1 <= k <= len(note["now"]):
            return "要指明改现在的第几条"
        old = note["now"][k - 1]
        note["now"][k - 1] = {"text": op["text"], "src": sorted(set(old["src"]) | set(op["sources"]), key=num)}
        note["past"].append({**old, "why": f"{op.get('reason', '改写')}，依据 {' '.join(op['sources'])}"})
    elif kind == "resolve":                                  # 待核对的那一条，有了定论
        k = op.get("open")
        if not isinstance(k, int) or not 1 <= k <= len(note["open"]):
            return "要指明解决待核对的第几条"
        old = note["open"].pop(k - 1)
        note["now"].append({"text": op["text"], "src": op["sources"]})
        note["past"].append({**old, "why": f"已核实，依据 {' '.join(op['sources'])}"})
    else:
        return f"不认识的维护动作：{kind}"
    save(note)
    return "ok"
