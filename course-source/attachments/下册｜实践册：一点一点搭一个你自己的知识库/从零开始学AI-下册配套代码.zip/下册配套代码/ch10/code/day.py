# day.py：观测者在后台上岗，你在前台照常说话、提问。看它们各干各的
import json, os, subprocess, sys, time
import llm, memory
from recall import recall

def wait_observer():
    t = time.time()
    while True:
        st = os.path.join(memory.HOME, "observer.json")
        last = memory.events()[-1]["id"]
        if os.path.exists(st) and memory.num(json.load(open(st))["seen"]) >= memory.num(last) - 1:
            return round(time.time() - t)
        time.sleep(1)

def show(*topics):
    for t in topics:
        print(memory.render(memory.load(t)))

def ask(q):
    t = time.time()
    a = recall(q)
    print(f"答（{time.time() - t:.1f} 秒）：{a}\n")

observer = subprocess.Popen([sys.executable, "observer.py", "--watch"], env={**os.environ, "OBSERVER_MODEL": "deepseek-v4.1-flash"})
print("① 前两周说过的十句话，一口气记下。前台只管记，整理交给后台的观测者")
for day, text in [
    ("11-02", "我最近在读《原子习惯》。两分钟规则就是每次只做两分钟，做完就停。"),
    ("11-02", "我每天早上 7:30 写三行日记。"),
    ("11-03", "读书会上我负责 11 月 9 日分享《原子习惯》，十分钟。"),
    ("11-04", "冷萃照论坛说的，泡 12 小时。"),
    ("11-05", "京都打算 12 月初去，住五晚。"),
    ("11-06", "读书会分享改到 11 月 16 日了，阿青说 9 号场地被占了。"),
    ("11-08", "冷萃我试了，用我这包深烘的豆子泡 12 小时太苦，泡 8 小时正好。浅烘的还没试。"),
    ("11-10", "早上写日记老忘，我改成睡前写了。"),
    ("11-11", "老周说下次周会改到周三；可小林发的周会纪要上写的是周四。"),
    ("11-12", "我之前把两分钟规则理解错了：它不是每次只做两分钟，而是把开始的门槛降到两分钟以内，开了头可以接着做。"),
]:
    memory.record(text, day=day)
print(f"   记完了。观测者整理完用了 {wait_observer()} 秒\n")
print("   现在的话题：", "、".join(memory.topics()), "\n")

print("② 问一个“为什么”")
ask("读书会的分享为什么改日子了？")

print("③ 又说了两句")
memory.record("浅烘的豆子我也试了，泡 12 小时刚好。", day="11-13")
memory.record("周会定了，就是周四，小林对过日历。", day="11-13")
print(f"   观测者整理完用了 {wait_observer()} 秒\n")
show(*memory.topics())

print("④ 再问一遍同一个“为什么”")
ask("读书会的分享为什么改日子了？")
time.sleep(4); wait_observer()
observer.terminate()
print("⑤ 观测者自己的工作记录：")
print(open(os.path.join(memory.HOME, "observer.log"), encoding="utf-8").read())
cand = os.path.join(memory.HOME, "candidates.jsonl")
print("⑥ 等人看的候选：", open(cand, encoding="utf-8").read() if os.path.exists(cand) else "没有")
print("前台：", llm.bill())
