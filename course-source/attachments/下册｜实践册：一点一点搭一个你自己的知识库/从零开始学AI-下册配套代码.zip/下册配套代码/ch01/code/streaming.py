# streaming.py：同一个问题，一次交完和一边写一边交，各问一遍。量两个时间：第一个字什么时候出来，全部什么时候写完
import time
from llm import chat, stream

Q = [{"role": "user", "content": "我想搭一个个人知识库，用来存读书笔记、网页剪藏和零碎想法。请用三点说说该从哪儿开始。"}]

t = time.time()
answer = chat(Q)
print(f"一次交完：第一个字和最后一个字都在 {time.time() - t:.1f} 秒时出现，共 {len(answer)} 个字\n")

t, first, pieces = time.time(), None, []
for piece in stream(Q):
    if first is None:
        first = time.time() - t
    pieces.append(piece)
    print(piece, end="", flush=True)
print(f"\n\n一边写一边交：第一个字在 {first:.1f} 秒时出现，全部写完在 {time.time() - t:.1f} 秒，"
      f"一共来了 {len(pieces)} 小段")
