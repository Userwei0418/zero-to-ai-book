# inbox_tools.py：收件箱的几样工具。add_clip 是第 3 章那一样的新版：编号不再按内容算，而是由任务定
import json, os, re
from toolbox import tool
from find import find, load

KB = os.environ.get("KB_DIR", "kb")
INBOX = os.environ.get("INBOX_DIR", "inbox")
TASK = {"id": None}                                           # 正在跑的是哪个任务，由 agent.py 填
OPS = lambda: os.path.join(KB, ".ops.json")

def op_of(item):
    """这一笔的编号：哪个任务，处理收件箱里的哪一件。模型怎么改写标题，编号都不变"""
    return f"{TASK['id']}:{item}"

def lookup(op):
    """去知识库那边查：这个编号办过没有。回执丢了的时候，靠它对账"""
    ops = json.load(open(OPS(), encoding="utf-8")) if os.path.exists(OPS()) else {}
    return ops.get(op)

@tool("列出收件箱里还没处理的剪藏")
def list_inbox():
    return "\n".join(sorted(os.listdir(INBOX))) or "收件箱是空的"

@tool("读收件箱里一件剪藏的原文", item="文件名，比如 coffee.txt")
def read_inbox(item):
    if item not in os.listdir(INBOX):
        return f"收件箱里没有 {item}"
    return open(os.path.join(INBOX, item), encoding="utf-8").read()

@tool("按意思在知识库里找，看看是不是已经记过类似的", question="一句话")
def find_notes(question):
    hits = find(question, load(KB), k=3)
    return "\n".join(f"{c['file']} 第 {c['line']} 行：{c['text']}（相似度 {s}）" for c, s in hits)

@tool("把收件箱里的一件整理好，存成一篇新笔记", writes=True,
      item="收件箱里的文件名", title="笔记标题，十来个字", text="整理好的正文，去掉评论和广告", source="来源")
def add_clip(item, title, text, source):
    op = op_of(item)
    if lookup(op):
        return f"这一笔已经办过了（{op}），在 {lookup(op)}，没有再写一遍"
    name = "剪藏-" + re.sub(r"[\\/:*?\"<>|\s]+", "", title)[:20] + ".md"
    tmp = os.path.join(KB, "." + name + ".tmp")
    open(tmp, "w", encoding="utf-8").write(f"# 剪藏：{title}\n来源：{source}\n\n{text.strip()}\n")
    os.replace(tmp, os.path.join(KB, name))
    ops = json.load(open(OPS(), encoding="utf-8")) if os.path.exists(OPS()) else {}
    ops[op] = name
    json.dump(ops, open(OPS(), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if os.environ.get("CRASH_AFTER_WRITE") == item:           # 演示用：写完了，回执还没记，程序就死了
        os._exit(1)
    return f"已存为 {name}"

@tool("这一件不值得存，跳过，并说明为什么", item="收件箱里的文件名", reason="一句话理由")
def skip_item(item, reason):
    return f"已跳过 {item}：{reason}"
