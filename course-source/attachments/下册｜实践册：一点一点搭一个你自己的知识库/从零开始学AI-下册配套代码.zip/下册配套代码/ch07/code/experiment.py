# experiment.py：同一件事，三种给规矩的办法，各跑几次。每次都从同一个知识库、同一个收件箱开始
# 三层检验：①读到了吗（交出去的规矩里有没有剪藏那一层）②照做了吗（存下的笔记，第一行写没写“相关：”）
#           ③结果对吗（广告跳过、切块存、冷萃存）
# 用法：python3 experiment.py 每种跑几次
import json, os, shutil, subprocess, sys
import llm, task, inbox_tools
from agent import run
from context_for import context_for, everything

N = int(sys.argv[1]) if len(sys.argv) > 1 else 5
MODES = {"不给规矩": None, "全部给": everything(), "按需给": context_for(["剪藏"], "整理收件箱")}

def fresh():
    shutil.rmtree("kb", ignore_errors=True); shutil.rmtree("tasks", ignore_errors=True)
    shutil.copytree("../../kb/notes", "kb", ignore=shutil.ignore_patterns("index.*", "vectors.json", ".ops.json"))
    subprocess.run([sys.executable, "build_index.py", "kb"], capture_output=True)

def judge(task_id):
    done, _ = task.state(task_id)
    got = {op.split(":", 1)[1]: e for op, e in done.items()}
    saved = {i: e["result"].replace("已存为 ", "") for i, e in got.items() if e["event"] == "done"}
    level1 = any("剪藏/AGENTS.md" in s for e in task.history(task_id) if e["event"] == "rules" for s in e["sources"])
    level2 = [i for i, f in saved.items()
              if "相关：" in open(os.path.join("kb", f), encoding="utf-8").read().split("\n\n", 1)[-1].splitlines()[0]]
    ad = got.get("ad.txt", {})
    level3 = (ad.get("event") == "skipped" and ad.get("reason", "").startswith("广告")
              and "chunking.txt" in saved and "coffee.txt" in saved)
    return level1, len(level2), len(saved), level3, got

os.environ["APPROVE"] = "yes"
rows = {}
for mode, rules in MODES.items():
    for k in range(N):
        fresh()
        before = llm.LEDGER["prompt"] + llm.LEDGER["completion"]
        card = task.new_card(f"{mode}{k}", goal="把收件箱里的剪藏整理进知识库。",
                             done_when=["收件箱里每一件都有结果：存了，或者跳过并写明理由"],
                             tools=["list_inbox", "read_inbox", "find_notes", "add_clip", "skip_item"],
                             writes=["add_clip"], budget={"rounds": 12, "tokens": 60000})
        run(card, lambda n, a: True, show=lambda s: None, rules=rules)
        l1, l2, nsaved, l3, got = judge(card["id"])
        cost = llm.LEDGER["prompt"] + llm.LEDGER["completion"] - before
        rows.setdefault(mode, []).append((l1, l2, nsaved, l3, cost))
        what = "，".join(f"{i}:{'存' if e['event'] == 'done' else '跳'}" for i, e in sorted(got.items()))
        print(f"{mode} 第{k + 1}次  {what}  相关行 {l2}/{nsaved}  结果{'对' if l3 else '不对'}  {cost} token", flush=True)

print("\n汇总（每种 %d 次）" % N)
for mode, rs in rows.items():
    l1 = "—" if MODES[mode] is None else f"{sum(r[0] for r in rs)}/{N}"
    l2 = f"{sum(r[1] for r in rs)}/{sum(r[2] for r in rs)}"
    print(f"  {mode}：①读到了 {l1}  ②存下的笔记里写了“相关：” {l2}  ③结果全对 {sum(r[3] for r in rs)}/{N}"
          f"  平均 {sum(r[4] for r in rs) // N} token")
