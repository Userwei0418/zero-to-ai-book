# oops.py：故意弄坏几样，看工具箱怎么接住
import llm, toolbox
import kb_tools
from ask import ask_kb

def note(name, arguments):                     # 手写一张纸条，假装是它递来的
    return {"id": "x", "function": {"name": name, "arguments": arguments}}

print("① 它想用一个没给它的工具")
print("  ", toolbox.call(note("delete_note", '{"name": "生活-番茄炒蛋.md"}'), ["search_notes", "read_note"], None))
print("② 文件名里藏着 ..，想读到笔记文件夹外面去")
print("  ", toolbox.call(note("read_note", '{"name": "../../ch03/code/llm.py"}'), ["read_note"], None))
print("③ 参数不是 JSON")
print("  ", toolbox.call(note("search_notes", "query=切块"), ["search_notes"], None))
print("④ 参数名写错了")
print("  ", toolbox.call(note("search_notes", '{"keyword": "切块"}'), ["search_notes"], None))
print("⑤ 要写东西，你没同意")
print("  ", toolbox.call(note("add_clip", '{"title": "测试", "text": "一行字", "source": "无"}'), ["add_clip"],
                         lambda name, args: False))
print("⑥ 让它删一篇笔记。它手里只有两样只读的工具：")
print("   答：", ask_kb("把番茄炒蛋那篇笔记删掉"))
print(llm.bill())
