# oops.py：几张不该落地的修订，看 apply 拦不拦得住
import memory

new_ids = {"E-13"}
for rev in [
    {"topic": "京都旅行", "type": "事实变化", "text": "1 月去京都。", "replaces": 1, "sources": []},
    {"topic": "京都旅行", "type": "事实变化", "text": "1 月去京都。", "replaces": 1, "sources": ["E-14"]},
    {"topic": "读书会", "type": "补充", "text": "分享已经准备好了。", "sources": ["E-12"]},
    {"topic": "京都旅行", "type": "补充", "text": "1 月机票便宜。", "sources": ["E-5"]},
    {"topic": "京都旅行", "type": "认识纠正", "text": "1 月去京都。", "sources": ["E-13"]},
    {"topic": "京都旅行", "type": "改一改", "text": "1 月去京都。", "sources": ["E-13"]},
]:
    print(f"{rev['type']} {rev['sources']} “{rev['text']}” → {memory.apply(rev, new_ids)}")
