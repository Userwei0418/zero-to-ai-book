# release.py：发版。四道关，一道不过就不发：
#   一 查有没有把密钥、私人文件打进包里   二 体检   三 一小份验收（真实模式）   四 打包，算指纹，写回执
# 用法：python3 release.py
import hashlib, json, os, re, subprocess, sys, tarfile, tempfile, time

PKG = "mykb"
VERSION = open(os.path.join(PKG, "mykb", "__init__.py")).read().split('"')[1]
GATE = [("鸡蛋要炒到几成熟再盛出来？", "生活-番茄炒蛋.md:2"), ("日本那趟住宿一晚大概多少钱？", "生活-京都旅行.md:4"),
        ("咖啡喝着发酸，该怎么调？", "剪藏-咖啡手冲参数.md:5"), ("提交说明写错了，还没推上去，怎么改？", "学习-Git撤销.md:4")]

def files():
    for root, dirs, names in os.walk(PKG):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for n in names:
            if n not in ("vectors.json", ".ops.json") and not n.endswith(".pyc"):
                yield os.path.join(root, n)

def stop(why):
    print(f"✗ 不发：{why}"); sys.exit(1)

print(f"发版 {PKG} {VERSION}")
# 一 密钥和私人文件
leak = [f for f in files() if re.search(r"sk-[A-Za-z0-9]{16,}|LLM_API_KEY\s*=\s*['\"]?[A-Za-z0-9_.-]{16,}", open(f, encoding="utf-8", errors="ignore").read())
        or os.path.basename(f) in (".env", "credentials.json")]
if leak: stop(f"这些文件里像有密钥：{leak}")
print(f"✓ 一 查过 {len(list(files()))} 个文件，没有密钥")

# 二 体检（真实模式，新建一个临时笔记文件夹）
tmp = tempfile.mkdtemp()
env = {**os.environ, "KB_DIR": os.path.join(tmp, "notes"), "KB_MODE": "real", "PYTHONPATH": PKG}
run = lambda *a: subprocess.run([sys.executable, "-m", "mykb", *a], env=env, capture_output=True, text=True)
run("init", env["KB_DIR"]); run("index")
r = run("doctor")
if r.returncode: stop("体检没过\n" + r.stdout)
print("✓ 二 体检通过")

# 三 一小份验收：真实模式，每题第一条要对
sys.path.insert(0, PKG); os.environ.update(env)
from mykb.find import find, load
fails = [(q, w, f"{t['file']}:{t['line']}") for q, w in GATE
         for t in [find(q, load(env["KB_DIR"]), k=1, rerank=True)[0][0]] if f"{t['file']}:{t['line']}" != w]
if fails: stop(f"验收没过：{fails}")
print(f"✓ 三 验收 {len(GATE)}/{len(GATE)}")

# 四 打包、算指纹、写回执
os.makedirs("dist", exist_ok=True)
tar = f"dist/{PKG}-{VERSION}.tar.gz"
with tarfile.open(tar, "w:gz") as t:
    for f in files():
        t.add(f)
sha = hashlib.sha256(open(tar, "rb").read()).hexdigest()
receipt = f"""# {PKG} {VERSION} 发版回执
时间：{time.strftime('%Y-%m-%d %H:%M')}
包：{tar}
SHA-256：{sha}
模型：{os.environ.get('LLM_MODEL', 'sensenova-6.8-flash-lite')}（回答）、qwen3.7-text-embedding（向量）、qwen3.7-text-rerank（重排）

## 验证到哪一级
- 本地已验证：体检通过；验收 {len(GATE)}/{len(GATE)}（找，真实模式，各 1 遍）；没有密钥进包
- 已实现、未在本次发版里验证：ask 的回答质量（第 13 章的完整验收另跑）；serve 接进 Claude Code / WorkBuddy（真实联调没做）
- 演示模式（KB_MODE=mock）：只保证能跑通流程，结果不能当真
"""
open(f"dist/RELEASE-{VERSION}.md", "w", encoding="utf-8").write(receipt)
print(f"✓ 四 打好了 {tar}\n  SHA-256 {sha[:16]}…\n  回执 dist/RELEASE-{VERSION}.md")
