# harness.py：毕业项目。一个跑 DeepSeek 的终端小助手，外壳是它自己的，里面接的全是这本下册做的东西
#   脑子：DeepSeek（第 1 章的 llm.py，换个模型名就行）
#   手：  通过 MCP 接上第 14 章的 mykb 服务（第 4 章）
#   做法：带着第 8 章的做法包目录，用到才取（第 8 章）
#   记性：你说的每一句，程序记进流水账（第 9 章）；读的时候看当前笔记（第 9、10 章）
#   会话：每个会话一个编号，每条消息一个请求编号；同一个请求交两次，只答一次（第 12 章）
#   刹车：一条消息最多来回几轮（第 6 章）
import json, os, subprocess, sys, time, uuid
import llm, memory, toolbox
from toolbox import tool

SKILLS = "skills"
SESSIONS = "sessions"
MODEL = os.environ.get("HARNESS_MODEL", "deepseek-v4.1-flash")

# ---------- 手：MCP 客户端（第 4 章的 MCPServer，一字未改的思路） ----------
class MCPServer:
    def __init__(self, command, env):
        self.proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, env=env)
        self.n = 0
        self.rpc("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "harness", "version": "0"}})
        self.proc.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n"); self.proc.stdin.flush()

    def rpc(self, method, params):
        self.n += 1
        self.proc.stdin.write(json.dumps({"jsonrpc": "2.0", "id": self.n, "method": method, "params": params}, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        reply = json.loads(self.proc.stdout.readline())
        if "error" in reply:
            raise RuntimeError(reply["error"]["message"])
        return reply["result"]

    def specs(self, prefix):
        return [{"type": "function", "function": {"name": prefix + t["name"], "description": t["description"], "parameters": t["inputSchema"]}}
                for t in self.rpc("tools/list", {})["tools"]]

    def call(self, name, args):
        r = self.rpc("tools/call", {"name": name, "arguments": args})
        return "\n".join(c["text"] for c in r["content"] if c["type"] == "text")

# ---------- 做法：第 8 章的三层 ----------
def catalog():
    rows = []
    for d in sorted(os.listdir(SKILLS)):
        head = open(os.path.join(SKILLS, d, "SKILL.md"), encoding="utf-8").read().split("---")[1]
        meta = dict(l.split(":", 1) for l in head.strip().splitlines() if ":" in l)
        rows.append(f"- {meta['name'].strip()}：{meta['description'].strip()}")
    return "\n".join(rows)

@tool("取出一个做法包的正文，照着做", name="做法包的名字")
def use_skill(name):
    p = os.path.join(SKILLS, name, "SKILL.md")
    return open(p, encoding="utf-8").read().split("---", 2)[2].strip() if os.path.exists(p) else f"没有 {name}"

# ---------- 记性：只读当前笔记；写由程序和后台的整理者负责 ----------
@tool("读我的记忆笔记：一个话题现在有效的理解", topic="话题名；不知道有哪些，填“目录”")
def read_memory(topic):
    if topic == "目录" or topic not in memory.topics():
        return "现有话题：" + "、".join(memory.topics()) if memory.topics() else "还没有任何记忆笔记"
    return memory.render(memory.load(topic))

# ---------- 会话 ----------
class Session:
    def __init__(self, sid, kb_server):
        self.sid, self.kb = sid, kb_server
        os.makedirs(SESSIONS, exist_ok=True)
        self.path = os.path.join(SESSIONS, sid + ".jsonl")
        self.turns = [json.loads(l) for l in open(self.path, encoding="utf-8")] if os.path.exists(self.path) else []
        self.tools = self.kb.specs("kb_") + toolbox.specs(["use_skill", "read_memory"])

    def send(self, text, request_id=None, show=print):
        request_id = request_id or uuid.uuid4().hex[:8]
        for t in self.turns:                                  # 同一个会话里，同一个请求编号：交回原来那条回复
            if t["request_id"] == request_id:
                return t["reply"] + "\n  （这条请求之前处理过了，交回原来的回复，没有再跑一遍）"
        memory.record(text, day=time.strftime("%m-%d"))      # 你说的每一句，先进流水账（程序做，不靠模型自觉）
        system = ("你是我的终端助手。可以用 kb_ 开头的工具查我的知识库；可以用 read_memory 看我告诉过你的事。"
                  "我说的每一句话，程序都会记下，后台会整理进记忆笔记，下次新开会话也查得到；你不用自己记，也不用说“记不住”。"
                  f"今天是 {time.strftime('%Y-%m-%d %A')}。"
                  "事情对得上下面哪个做法包，先用 use_skill 取出来照着做：\n" + catalog() +
                  "\n回答要标出处；查不到就说查不到。")
        history = [m for t in self.turns[-4:] for m in ({"role": "user", "content": t["text"]}, {"role": "assistant", "content": t["reply"]})]
        messages = [{"role": "system", "content": system}] + history + [{"role": "user", "content": text}]
        reply = "（来回了 8 轮还没答完，先停在这儿）"
        for _ in range(8):                                    # 刹车：最多 8 轮
            msg = llm.chat_msg(messages, tools=self.tools, model=MODEL)
            notes = msg.get("tool_calls") or []
            if not notes:
                reply = msg.get("content") or ""
                break
            messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": notes})
            for n in notes:
                name, args = n["function"]["name"], json.loads(n["function"]["arguments"] or "{}")
                result = self.kb.call(name[3:], args) if name.startswith("kb_") else toolbox.call(n, ["use_skill", "read_memory"], None)
                show(f"    · {name} {json.dumps(args, ensure_ascii=False)[:50]}")
                messages.append({"role": "tool", "tool_call_id": n["id"], "content": result})
        turn = {"request_id": request_id, "text": text, "reply": reply, "at": time.strftime("%H:%M:%S")}
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(turn, ensure_ascii=False) + "\n")
        self.turns.append(turn)
        return reply

def start_kb():
    env = {**os.environ, "PYTHONPATH": os.path.abspath("../../ch14/code/mykb"), "LLM_MODEL": "sensenova-6.8-flash-lite"}
    return MCPServer([sys.executable, "-m", "mykb", "serve"], env)

if __name__ == "__main__":                                    # 交互：python3 harness.py [会话编号]
    s = Session(sys.argv[1] if len(sys.argv) > 1 else uuid.uuid4().hex[:6], start_kb())
    print(f"会话 {s.sid}。说点什么（空行退出）")
    while (line := input("你：").strip()):
        print("助手：", s.send(line))
