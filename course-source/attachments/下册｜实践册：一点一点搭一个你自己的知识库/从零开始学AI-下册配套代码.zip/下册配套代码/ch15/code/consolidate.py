# consolidate.py：整理一次。把“已整理至”之后的新记录交给模型，让它提修订；程序逐条验过再落地
# 用法：python3 consolidate.py
import json, os
import llm, memory

def consolidate(show=print, model=None, retry=False):
    covered = min((memory.load(t)["covered"] for t in memory.topics()), key=memory.num, default="E-0")
    new = [e for e in memory.events() if memory.num(e["id"]) > memory.num(covered) and e["kind"] == "用户"]
    if not new:
        show("没有新记录要整理"); return
    current = "\n\n".join(memory.render(memory.load(t)) for t in memory.topics()) or "（还没有任何笔记）"
    ask = ("你在帮我维护记忆笔记。下面是现有的笔记，和这之后的新记录。\n"
           "请对每一条新记录，判断它对笔记意味着什么，给出修订，只输出 JSON："
           '{"revisions": [{"topic": "话题", "type": "补充|事实变化|认识纠正|条件细化|未决冲突", '
           '"text": "写进笔记的一句话", "replaces": 现在的第几条（只有事实变化、认识纠正要填）, "sources": ["E-n"]}]}\n'
           "类型的意思：补充=原来没有的新信息；事实变化=情况变了，旧的不是错而是过去了；认识纠正=原来理解错了；"
           "条件细化=在某种条件下另有说法，两条都对；未决冲突=说法打架，定不下来。\n"
           "话题尽量用现有的；sources 只能填新记录里的编号。\n"
           "第 15 章加的两条：只记我陈述的事实、计划、偏好；我问的问题、让你做的事，不用进笔记，跳过即可。"
           "相对的日子（明天、下周三）按那条记录的日期换成具体日期，比如“11 月 18 日（周三）”。\n\n"
           f"【现有笔记】\n{current}\n\n【新记录】\n" + "\n".join(f"{e['id']}（{e['day']}）：{e['text']}" for e in new))
    revs = llm.chat_json([{"role": "user", "content": ask}], model=model).get("revisions", [])
    new_ids = {e["id"] for e in new}
    rejected = []
    for r in revs:
        result = memory.apply(r, new_ids)
        show(f"  {r.get('type')}｜{r.get('topic')}｜{r.get('text')} {r.get('sources')}" + ("" if result == "ok" else f"  ✗ 没改：{result}"))
        if result != "ok":
            rejected.append((r, result))
    if rejected and retry:                                   # 第 10 章：被退回的，带着理由交回去重提一次。不偷偷修，也不无限重来
        again = ("下面这些修订被程序退回了，理由写在后面。请对照现有笔记改正后重提，只输出 JSON，格式同上：{\"revisions\": [...]}；确实改不了的就不要再提。\n\n"
                 f"【现有笔记】\n" + "\n\n".join(memory.render(memory.load(t)) for t in memory.topics()) + "\n\n【被退回的】\n"
                 + "\n".join(f"{json.dumps(r, ensure_ascii=False)} → {why}" for r, why in rejected))
        revs2 = llm.chat_json([{"role": "user", "content": again}], model=model).get("revisions", [])
        rejected = []
        for r in revs2:
            result = memory.apply(r, new_ids)
            show(f"  重提 {r.get('type')}｜{r.get('topic')}｜{r.get('text')} {r.get('sources')}" + ("" if result == "ok" else f"  ✗ 还是没改：{result}"))
            if result != "ok":
                rejected.append((r, result))
    for r, why in rejected:                                  # 还是不行的：放进候选，等人看
        with open(os.path.join(memory.HOME, "candidates.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps({"rev": r, "why": why}, ensure_ascii=False) + "\n")
    last = new[-1]["id"]
    for t in memory.topics():                                 # 这一批都看过了：每篇笔记的边界推到最后一条
        n = memory.load(t); n["covered"] = last; memory.save(n)
    memory.record(f"整理了 {new[0]['id']} 到 {last}", kind="整理")   # 整理这件事本身也记一笔，但标明是整理产物

if __name__ == "__main__":
    consolidate()
    print(llm.bill())
