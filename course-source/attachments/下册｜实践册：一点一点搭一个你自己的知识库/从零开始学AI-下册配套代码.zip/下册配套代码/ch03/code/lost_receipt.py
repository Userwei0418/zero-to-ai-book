# lost_receipt.py：写进去了，回执却丢了。再来一次，会不会写两篇？
import os
import kb_tools

args = dict(title="切块的三个经验", text="按段落切；块之间留一点重叠；大小看问题。", source="一篇博客")
print("第一次：", kb_tools.add_clip(**args))
print("（假装回执在路上丢了。你不知道写没写进去，于是再来一次）")
print("第二次：", kb_tools.add_clip(**args))
print("文件夹里叫这个名字的笔记有几篇：", sum(n.startswith("剪藏-切块的三个经验") for n in os.listdir(kb_tools.KB)))
