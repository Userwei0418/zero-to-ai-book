# 学习：Git 里怎么撤销
- 改了还没 add：git restore 文件名
- add 了还没 commit：git restore --staged 文件名
- commit 了想改说明：git commit --amend
- 已经推上去了：别改历史，用 git revert 新提交一个“反操作”。
