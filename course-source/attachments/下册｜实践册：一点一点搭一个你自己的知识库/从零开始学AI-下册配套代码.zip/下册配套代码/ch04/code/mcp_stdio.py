# mcp_stdio.py：把第 3 章那个工具箱，变成一个任何 MCP 客户端都接得上的服务。只用自带的库
# 上册实践篇写过一版，这里改成直接读工具箱：哪些工具、会不会写，都从登记里来
# 通信方式是 stdio：客户端把这个程序启动起来，往它的标准输入写一行 JSON，从标准输出读一行 JSON
# 新老两种客户端都认：
#   新的（2026-07-28 版）：每个请求自带协议版本，先问一句 server/discover
#   老的（2025 年及以前的版本）：先 initialize 握个手，再干活。眼下不少客户端还说这一种
import json, sys

MODERN = "2026-07-28"
LEGACY = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"]
META = "io.modelcontextprotocol/"

def mcp_tools(registry, names):
    """把第 3 章写给模型看的说明书，换成 MCP 的写法：外壳不同，里面那份参数说明是同一份
    会不会改东西，也一并告诉对面（annotations），让对面的助手知道哪样该先问人"""
    out = []
    for n in names:
        f = registry[n]["spec"]["function"]
        out.append({"name": n, "description": f["description"], "inputSchema": f["parameters"],
                    "annotations": {"readOnlyHint": not registry[n]["writes"]}})
    return out

def call(registry, names, params):
    name, args = params.get("name"), params.get("arguments") or {}
    if name not in names:
        raise LookupError(f"Unknown tool: {name}")
    try:
        text, failed = str(registry[name]["fn"](**args)), False
    except Exception as error:                     # 工具自己办砸了，不算协议错：照常回话，标上 isError
        text, failed = f"出错：{error}", True
    return {"content": [{"type": "text", "text": text}], "isError": failed}

def handle(request, name, registry, names):
    method, params = request.get("method"), request.get("params") or {}
    meta = params.get("_meta") or {}
    modern = META + "protocolVersion" in meta
    if method == "initialize":                     # 老客户端：握手。它说它会哪一版，我们挑一版两边都会的
        asked = params.get("protocolVersion")
        return {"protocolVersion": asked if asked in LEGACY else LEGACY[0],
                "capabilities": {"tools": {}}, "serverInfo": {"name": name, "version": "1.0"}}
    if method == "server/discover":                # 新客户端：你是谁，会说哪几版
        return {"resultType": "complete", "supportedVersions": [MODERN] + LEGACY, "capabilities": {"tools": {}},
                "_meta": {META + "serverInfo": {"name": name, "version": "1.0"}}}
    if method == "ping":
        return {}
    if method == "tools/list":
        result = {"tools": mcp_tools(registry, names)}
    elif method == "tools/call":
        result = call(registry, names, params)
    else:
        raise NotImplementedError(f"Method not found: {method}")
    return {"resultType": "complete", **result} if modern else result

def serve(name, registry, names):
    for line in sys.stdin:                         # 客户端关掉标准输入，循环自然结束，程序退出
        if not line.strip():
            continue
        request = json.loads(line)
        if "id" not in request:                    # 没有 id 的是通知（比如老客户端握完手说的 initialized），不用回
            continue
        try:
            reply = {"result": handle(request, name, registry, names)}
        except LookupError as e:
            reply = {"error": {"code": -32602, "message": str(e)}}
        except NotImplementedError as e:
            reply = {"error": {"code": -32601, "message": str(e)}}
        print(json.dumps({"jsonrpc": "2.0", "id": request["id"], **reply}, ensure_ascii=False), flush=True)
