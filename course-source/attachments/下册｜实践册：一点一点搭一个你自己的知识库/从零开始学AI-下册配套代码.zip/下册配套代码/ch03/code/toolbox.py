# toolbox.py：一个小工具箱。函数要用 @tool 登记了，才算工具；登记的时候写清楚它会不会改东西
# 模型只看得到说明书（specs），看不到代码；它递来的纸条，由 call 去核对、去办
import json

REGISTRY = {}

def tool(about, writes=False, **params):
    """登记一个工具。about 和 params 是写给模型看的；writes=True 的，每次用之前都要问人"""
    def register(fn):
        REGISTRY[fn.__name__] = {"fn": fn, "writes": writes, "params": params, "spec": {
            "type": "function", "function": {"name": fn.__name__, "description": about, "parameters": {
                "type": "object", "required": list(params),
                "properties": {k: {"type": "string", "description": v} for k, v in params.items()}}}}}
        return fn
    return register

def specs(names):
    """这一次对话交给它哪几样。没交的，它连名字都不知道"""
    return [REGISTRY[n]["spec"] for n in names]

def call(note, allowed, ask):
    """办一张纸条。办不了的，把原因写成一句话交回去，让它自己看着办，程序不崩"""
    name = note["function"]["name"]
    if name not in allowed:
        return f"没有叫 {name} 的工具。你能用的只有：{'、'.join(allowed)}"
    entry = REGISTRY[name]
    try:
        args = json.loads(note["function"].get("arguments") or "{}")
    except ValueError:
        return "参数不是合法的 JSON，请重写"
    missing = [k for k in entry["params"] if k not in args]
    extra = [k for k in args if k not in entry["params"]]
    if missing or extra:
        return f"参数不对：缺 {missing or '无'}，多 {extra or '无'}"
    if entry["writes"] and not ask(name, args):
        return "用户没有同意这一次。不要换个说法再试，先问问用户想怎么办"
    try:
        return str(entry["fn"](**args))
    except Exception as e:
        return f"出错了：{e}"
