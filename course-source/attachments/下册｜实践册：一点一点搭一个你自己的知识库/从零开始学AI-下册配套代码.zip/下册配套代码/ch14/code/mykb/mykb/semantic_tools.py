# semantic_tools.py：把“按意思找”登记进工具箱。第 4 章的服务不用改，多开一个名字就行
from .toolbox import tool
from . import kb_tools
from .find import find, load

@tool("按意思在我的笔记里找，不用猜关键词。交回最相关的几条，每条带出处：文件名和行号",
      question="你想找什么，用一句话说，比如：番茄炒蛋要不要放糖")
def find_notes(question):
    hits = find(question, load(kb_tools.KB), k=4, rerank=True)
    return "\n".join(f"{c['file']} 第 {c['line']} 行：{c['text']}（相关度 {s}）" for c, s in hits)
