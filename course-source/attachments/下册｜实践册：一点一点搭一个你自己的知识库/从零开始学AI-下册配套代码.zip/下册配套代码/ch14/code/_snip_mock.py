# mock.py：演示模式。不联网、不要密钥，给没有接口的人先把整套东西跑起来看看
# 它回的东西都是假的，每一句都带着【演示】两个字：演示模式的结果，永远不能当真
import hashlib, math

def embed(texts):
    """把字拆成两两一组，散到 256 个格子里。意思它不懂，可字面像的，数也像"""
    out = []
    for t in texts:
        v = [0.0] * 256
        for a, b in zip(t, t[1:]):
            v[int(hashlib.md5((a + b).encode()).hexdigest(), 16) % 256] += 1
        n = math.sqrt(sum(x * x for x in v)) or 1
        out.append([x / n for x in v])
    return out

def rerank(query, docs):
    q = set(zip(query, query[1:]))
    return sorted(((i, len(q & set(zip(d, d[1:]))) / (len(q) or 1)) for i, d in enumerate(docs)), key=lambda x: -x[1])

def chat(messages):
    last = messages[-1]["content"]
    lines = [l for l in last.splitlines() if l.startswith("[") and ".md:" in l]
    return "【演示】" + (f"笔记里最像的一条：{lines[0]}" if lines else "演示模式不会真的回答问题。")
