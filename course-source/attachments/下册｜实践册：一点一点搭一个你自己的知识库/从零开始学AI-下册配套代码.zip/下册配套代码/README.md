# 《从零开始学 AI》下册配套代码

一个文件夹，跟着下册十五章，一点一点搭一个你自己的知识库。

## 里面有什么

```
下册配套代码/
  README.md        就是这一份
  kb/notes/        样例知识库：十六篇笔记。换成你自己的笔记，会更有意思
  ch01/code/ … ch15/code/   每一章的代码，和书里印的那些真实输出（_out_*.txt）
```

每一章的代码都在自己的文件夹里，从 `chNN/code` 里运行。书里每一段代码、每一段输出，都在对应章的文件夹里找得到：`{{CODE:名字}}` 就是 `名字.py`，`{{OUT:名字}}` 就是 `名字.txt`。

| 章 | 做了什么 | 从哪儿开始跑 |
|-|-|-|
| 1 | 和模型说上话，一本小账，给笔记写目录 | `python3 raw.py`、`python3 index_kb.py ../../kb/notes` |
| 2 | 按格式回答，词表，小考卷 | `python3 vocab.py ../../kb/notes`、`python3 evaluate.py vocab_ask 模型名` |
| 3 | 工具箱，问答循环，存剪藏要先问你 | `python3 ask.py "问题"`、`python3 clip.py clip_sample.txt` |
| 4 | 做成 MCP 服务，接进别的助手 | `python3 try_server.py`、`python3 mcp_client.py "问题" python3 kb_server.py` |
| 5 | 按意思找，带出处回答，核对出处 | `python3 build_index.py 笔记文件夹`、`python3 answer.py 笔记文件夹 "问题"` |
| 6 | 任务卡、流水账、刹车、对账 | `KB_DIR=… INBOX_DIR=inbox APPROVE=yes python3 agent.py t1` |
| 7 | 分层规矩、按需给、三层检验 | `python3 context_for.py`、`python3 experiment.py 3` |
| 8 | 做法包、封版、升级计划 | `python3 assistant.py "要它做的事"`、`bash lifecycle.sh` |
| 9 | 记性：原话和当前笔记，五种修订 | `python3 week1.py`、`python3 week2.py`、`python3 ask_week3.py` |
| 10 | 后台的独立整理者 | `python3 day.py` |
| 11 | 记忆分空间放，经验卡 | `python3 life.py` |
| 12 | 几个助手一起干，单写，后台 | `KB_DIR=… python3 run.py 3 r-001` |
| 13 | 验收：考卷、判官、对比报告 | `python3 calibrate.py`、`KB_DIR=… python3 accept.py 基线 3` |
| 14 | 打包交给别人 | `cd mykb && python3 -m mykb doctor`；`python3 release.py`；`bash install_test.sh dist/mykb-0.1.0.tar.gz` |
| 15 | 毕业项目：一个终端小助手 | `KB_DIR=… python3 graduation.py`；交互：`python3 harness.py` |

有几章会在自己的文件夹里写东西（索引、流水账、草稿）。书里演示时，用的是知识库的一份副本，你也可以先 `cp -R ../../kb/notes kb` 再把 `KB_DIR` 指过去，免得改动样例笔记。

## 开工之前

- **Python 3.9 或更新。**只用 Python 自带的库，不用装任何包。
- **一个模型接口**，兼容 OpenAI 的格式。三样东西放进环境变量，**不要写进任何文件**：

```bash
export LLM_BASE_URL=https://你的平台地址/v1
export LLM_API_KEY=你的密钥
export LLM_MODEL=模型名
```

- **从第 5 章起**，还要用到平台上的向量模型和重排模型（`/embeddings`、`/rerank` 两个接口）。书里用的是 `qwen3.7-text-embedding` 和 `qwen3.7-text-rerank`；你的平台名字不同，就设 `EMBED_MODEL`、`RERANK_MODEL`。没有重排接口的平台，第 5 章以后找东西那几步要换个平台跑。
- 第 10、12、13、15 章有一部分用的是 `deepseek-v4.1-flash`，在代码里写着，换成你平台上有的模型即可。

书里第 1 章用的是平台的旧地址，第 2 章起换到了新地址；模型名也跟着变了。代码一行没动，换的只是环境变量。你那边的平台和模型，以你手上的为准。

## 这些代码验证到了哪一步

书里一直区分三级：**已实现**（代码里有）、**本地已验证**（在作者的环境里跑过、留了证据）、**真实联调**（和真实的外部系统接起来跑过）。

- 每一章的代码，都在作者的电脑上（macOS，Python 3.9.6）真实跑过，输出就是文件夹里的 `_out_*.txt`。这是“本地已验证”。
- 第 14 章的包，在一个空文件夹里从头装过一遍：体检、演示模式、真实模式、MCP 服务都通过。
- **接进 Claude Code、WorkBuddy 和跑 DeepSeek 的终端助手：只做到“已实现”，没有真实联调。**第 4 章给了命令和配置，作者的电脑上没能实测。
- 没在 Windows、Linux 和别的 Python 版本上试过；样例只有十六篇笔记，笔记多到几千篇时效果如何，没测过。
- 模型的回答每次会有出入。你跑出来的结果和书里的不完全一样，是正常的；第 6、13 章专门讲了这件事。

## 已知的缺口

书里照实留着，也写进了各章的“改一改”：第 9 章往后，记忆笔记没有“合并”动作；第 15 章的小助手还读不到记忆锚点背后的原话；第 11 章主人同意改期以后，旧的那条没有按“事实变化”换掉；第 14 章的包只含建索引、提问和 MCP 服务，没有第 15 章的小助手。

## 安全

这个包里没有任何密钥。你自己用的时候，密钥也只放在环境变量里。第 14 章的 `release.py` 会在打包前扫一遍，像密钥的东西一律不发。
