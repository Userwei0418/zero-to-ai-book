# oops.py：故意弄坏两样，看核对接不接得住
import shutil
import llm
from answer import answer, check

folder = "kb5"
print("① 笔记改了，索引没重建")
path = folder + "/生活-番茄炒蛋.md"
backup = open(path, encoding="utf-8").read()
open(path, "w", encoding="utf-8").write(backup.replace("加一小勺糖", "不放糖，番茄本身够酸甜"))
reply, shown = answer("番茄炒蛋要不要放点甜的？", folder)
print("   答：", reply)
print("   核对：", "；".join(check(reply, shown, folder)) or "每条出处都对得上")
open(path, "w", encoding="utf-8").write(backup)

print("② 出处是编的")
reply, shown = answer("京都待办里有什么？", folder)
fake = reply + " 另外酒店已经订好了。[生活-京都旅行.md:9]"
print("   答（末尾那句是我手动加的）：", fake)
print("   核对：", "；".join(check(fake, shown, folder)) or "每条出处都对得上")
print(llm.bill())
