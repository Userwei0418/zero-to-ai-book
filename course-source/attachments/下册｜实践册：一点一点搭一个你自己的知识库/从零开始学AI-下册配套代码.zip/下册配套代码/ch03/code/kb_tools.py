# kb_tools.py：知识库的三样工具。两样只读，一样会写
# 这些都是普通函数，不认识模型；@tool 那一行，是写给模型看的说明书
import hashlib, json, os, re
from toolbox import tool

KB = os.environ.get("KB_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "kb", "notes"))

def _path(name):
    """只认笔记文件夹里的 .md 文件。带 / 或 .. 的名字一律不认：它够不着文件夹外面"""
    if not re.fullmatch(r"[^/\\]+\.md", name or "") or ".." in name:
        raise ValueError(f"不认这个名字：{name!r}，只能是笔记文件夹里的一个 .md 文件")
    return os.path.join(KB, name)

@tool("按关键词在我的笔记里找。几个关键词用空格隔开，都出现的才算。交回文件名、行号和命中的那一行",
      query="关键词，比如：切块 重叠")
def search_notes(query):
    words = query.split()
    hits = []
    for name in sorted(os.listdir(KB)):
        if not name.endswith(".md") or name == "index.md":
            continue
        lines = open(os.path.join(KB, name), encoding="utf-8").read().splitlines()
        if all(any(w in l for l in lines) for w in words):
            for i, l in enumerate(lines, 1):
                if any(w in l for w in words):
                    hits.append(f"{name} 第 {i} 行：{l.strip()}")
    return "\n".join(hits[:12]) or f"没有一篇笔记同时含有：{'、'.join(words)}。可以少用几个词，或者换个说法"

@tool("读一篇笔记的全文，每行前面带行号", name="笔记的文件名，比如：剪藏-RAG入门.md")
def read_note(name):
    path = _path(name)
    if not os.path.exists(path):
        return f"没有叫 {name} 的笔记，先用 search_notes 找一找"
    return "\n".join(f"{i:>3}  {l}" for i, l in enumerate(open(path, encoding="utf-8").read().splitlines(), 1))

OPS = os.path.join(KB, ".ops.json")      # 写过的每一笔：编号 → 写到了哪儿

@tool("把一段剪藏存成一篇新笔记。同样的内容存两次，只会有一篇", writes=True,
      title="笔记标题，十来个字", text="笔记正文", source="从哪儿来的：网址或者书名")
def add_clip(title, text, source):
    op = hashlib.sha1(f"{title}\n{text}".encode("utf-8")).hexdigest()[:8]   # 同样的内容，同一个编号
    ops = json.load(open(OPS, encoding="utf-8")) if os.path.exists(OPS) else {}
    if op in ops:
        return f"这一笔已经写过了（编号 {op}），在 {ops[op]}，没有再写一遍"
    name = "剪藏-" + re.sub(r"[\\/:*?\"<>|\s]+", "", title)[:20] + ".md"
    _path(name)
    if os.path.exists(os.path.join(KB, name)):
        name = name[:-3] + "-" + op + ".md"                         # 同名但内容不同：不覆盖，另起一篇
    tmp = os.path.join(KB, "." + name + ".tmp")
    open(tmp, "w", encoding="utf-8").write(f"# 剪藏：{title}\n来源：{source}\n\n{text.strip()}\n")
    os.replace(tmp, os.path.join(KB, name))                         # 先写到旁边，写完一下子换过去：不会留下半篇
    ops[op] = name
    json.dump(ops, open(OPS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return f"已存为 {name}（编号 {op}）"
